/*
 * PhoneGap is available under *either* the terms of the modified BSD license *or* the
 * MIT License (2008). See http://opensource.org/licenses/alphabetical for full text.
 *
 * Copyright 2012, Andrew Lunny, Adobe Systems
 * Copyright (c) 2005-2010, Nitobi Software Inc.
 * Copyright (c) 2011, IBM Corporation
 * (c) 2010 Jesse MacFadyen, Nitobi
 */


var Entertainment = (function (gap) {
                 function isFunction(f) {
                 return typeof f === "function";
                 }
                 
                 // placeholder and constants
                 function Entertainment() {}
                 
                 
                 /**
                  * Maintain API consistency with iOS
                  */
                 Entertainment.install = function () {
                 console.log('Entertainment.install is deprecated');
                 }
                 
/**
                                      * Load ChildBrowser
                                      */
                     
                     
                     
                     if (!window.plugins) {
                     window.plugins = {};
                     }
                     if (!window.plugins.Entertainment) {
                     window.plugins.Entertainment = new Entertainment();
                     }
                     
                     
                
                 return Entertainment;
                 });


Entertainment.prototype.Photo = function(successCallback, failureCallback) {
    return   cordova.exec(successCallback, failureCallback, "EntertainmentPlugin", "Photo", []);
};


Entertainment.prototype.Video = function(successCallback, failureCallback) {
    return   cordova.exec(successCallback, failureCallback, "EntertainmentPlugin", "Video", []);
};

Entertainment.prototype.Gallery = function(successCallback, failureCallback, RetValue, Path, FileName, cameraFlag) {
    return   cordova.exec(successCallback, failureCallback, "EntertainmentPlugin", "Gallery", [RetValue, Path, FileName, cameraFlag]);
};

Entertainment.prototype.GalleryPhoto = function(successCallback, failureCallback) {
    return   cordova.exec(successCallback, failureCallback, "EntertainmentPlugin", "galleryphoto", []);
};

Entertainment.prototype.GalleryVideo = function(successCallback, failureCallback) {
    return   cordova.exec(successCallback, failureCallback, "EntertainmentPlugin", "galleryvideo", []);
};