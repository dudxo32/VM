var explorer_lang_title_server = "";
var explorer_lang_title_local = "";

//explorerForm 어두워지게
function explorerForm_fadeOut() {
	// 어두워졌을 시, 파일리스트 클릭 안되도록 설정
	$('#explorerList li').css('pointer-events', 'none');
	
	$('#explorerForm').css('-webkit-transition', 'opacity 0.5s ease-in');
	$('#explorerForm').css('-webkit-transition', 'background-color 0.5s ease-in');
	$('#explorerForm').css('opacity', '0.5');
	$('#explorerForm').css('background-color', '#999');
}

// explorerForm 밝아지게
function explorerForm_fadeIn() {
	// 밝아졌을 시, 파일리스트 클릭되도록 재설정
	$('#explorerList li').css('pointer-events', 'auto');
	
	$('#explorerForm').css('-webkit-transition', 'opacity 0.5s ease-in');
	$('#explorerForm').css('-webkit-transition', 'background-color 0.3s ease-in');
	$('#explorerForm').css('opacity', '1');
	$('#explorerForm').css('background-color', '');
}

// 문서함 변경 선택창
function open_document_select() {
	$('#document_select').slideToggle("fast");
}

// 좌측문서 swipe 효과로 닫기
function slideEffect() {
	menuOpen= false;
	explorerForm_fadeIn();
	$('.slide-in').toggleClass('on');		
	$('#main-container').toggleClass('on');
	Hammer(document.getElementById('main-container')).on('swipeleft', slideMenu);
}

// explorerForm에서 서버문서함으로 변경 선택
function select_server() {
	open_document_select();
	change_to_server();
}

// 좌측메뉴에서 서버문서함으로 변경 선택
function menu_select_server() {
	slideEffect();
	change_to_server();
}

/* 서버문서함으로 변경
 * select_server() -> change_to_server()
 */
function change_to_server() {
	change_to_server_form();
	getDriveList();
}

function change_to_server_form() {
	$('#explorerList').css('display', 'block');
	$('#localList').css('display', 'none');
	
	$('#explorerTool_normal').css('display', 'table');
	$('#explorerTool_work').css('display', 'none');
}

// explorerForm에서 로컬문서함으로 변경 선택
function select_local() {
	open_document_select();
	change_to_local();
}

// 좌측메뉴에서 로컬문서함으로 변경 선택
function menu_select_local() {
	slideEffect();
	change_to_local();
}

/* 로컬문서함으로 변경
 * select_local() -> change_to_local()
 */
function change_to_local() {
	$('#explorerList').css('display', 'none');
	$('#localList').css('display', 'block');
	
	$('#explorerTool_normal').css('display', 'none');
	$('#explorerTool_work').css('display', 'table');
	
	getLocalList();
}

// 단일파일 모드
function single_mode() {
	// 탐색기 상단
	$('#explorerTitle_normal').css('display', 'table-row');
	$('#explorerTitle_select').css('display', 'none');
	$('#explorerTitle_work').css('display', 'none');
	// 리스트 버튼
	$('.file_func').css('display', 'block');
	$('.file_select').css('display', 'none');
	$('.file_noneFunc').css('display', 'none');
	// 하단 툴바
	if(nowPage == "local") {
		$('#explorerTool_normal').css('display', 'none');
		$('#explorerTool_selected').css('display', 'none');
		$('#explorerTool_work').css('display', 'table');
	} else {
		$('#explorerTool_normal').css('display', 'table');
		$('#explorerTool_selected').css('display', 'none');
		$('#explorerTool_work').css('display', 'none');
	}
	
	// 파일 전체 선택이였을 경우 해제
	$('#multiple_lang_allSelcet').css('color', '#5E5E5E');
	
	multiple_all_cancel();
}

// 다중파일 선택 모드
function multiple_mode() {
    multipleFlag = "true";
	// 탐색기 상단
	$('#explorerTitle_normal').css('display', 'none');
	$('#explorerTitle_select').css('display', 'table-row');
	$('#explorerTitle_work').css('display', 'none');
	// 리스트 버튼
	$('.file_func').css('display', 'none');
	$('.file_select').css('display', 'block');
	$('.file_noneFunc').css('display', 'none');
	// 하단 툴바
	$('#explorerTool_normal').css('display', 'none');
	$('#explorerTool_selected').css('display', 'table');
	$('#explorerTool_work').css('display', 'none');
}

// 파일작업 모드
function work_mode() {
	// 탐색기 상단
	$('#explorerTitle_normal').css('display', 'none');
	$('#explorerTitle_select').css('display', 'none');
	$('#explorerTitle_work').css('display', 'table-row');
	// 리스트 버튼
	$('.file_func').css('display', 'none');
	$('.file_select').css('display', 'none');
	$('.file_noneFunc').css('display', 'block');
	// 하단 툴바
	$('#explorerTool_normal').css('display', 'none');
	$('#explorerTool_selected').css('display', 'none');
	$('#explorerTool_work').css('display', 'table');
}

// 파일 전체 선택
function multiple_all() {
	if(nowPage == "server") {
		check_list = $('#explorerList input:checkbox');
		checked_list= $('#explorerList input:checkbox:checked');
	} else if(nowPage == "local") {
		check_list = $('#localList input:checkbox');
		checked_list= $('#localList input:checkbox:checked');
	}
	
	if(check_list.length == checked_list.length) {
		for(i=0; i< check_list.length; i++) {
			check_list[i].checked= false;
			$('#multiple_lang_allSelcet').css('color', '#5E5E5E');
		}
	} else {
		for(i=0; i< check_list.length; i++) {
			check_list[i].checked= true;
			$('#multiple_lang_allSelcet').css('color', 'red');
		}
	}
}

// 파일 전체 선택 취소
function multiple_all_cancel() {
	if(nowPage == "server")
		check_list = $("#explorerList input:checkbox");
	else if(nowPage == "local")
		check_list = $("#localList input:checkbox");
	
	for(i=0; i< check_list.length; i++) {
		check_list[i].checked= false;
	}
	
	$('#multiple_lang_allSelcet').css('color', '#5E5E5E');
}

// 전체 선택됬을 시 '전체'버튼 색변경
function li_select(object) {
	if(nowPage == "server") {
		check_list = $('#explorerList input:checkbox');
		checked_list= $('#explorerList input:checkbox:checked');
	} else if(nowPage == 'local') {
		check_list = $('#localList input:checkbox');
		checked_list= $('#localList input:checkbox:checked');
	}

	for(i=0; i < check_list.length; i++) {
		if(check_list[i].id == object)
			target= check_list[i].checked;
	}

	if(target) {
		$('#multiple_lang_allSelcet').css('color', '#5E5E5E');
	} else {
		if(check_list.length == checked_list.length+1)
			$('#multiple_lang_allSelcet').css('color', 'red');
		else
			$('#multiple_lang_allSelcet').css('color', '#5E5E5E');
	}
}

//파일 목록 정렬창 표시
function sortDialog() {
	$('.sortDialog').css('display', 'block');
}

// 단일파일 작업창 표시
function fileFuncDialog(drive_name) {
	if(nowPage == "server")
		liList = $("#explorerList input:checkbox");
	else if(nowPage == "local")
		liList = $("#localList input:checkbox");
	
	for(i=0; i< liList.length; i++) {
		if(liList[i].id == drive_name)
			liList[i].checked= true;
	}
	
	$('#fileFunc_lang_title').text(drive_name);
	$('.fileFuncDialog').css('display', 'block');
}

// 카메라 작업 창 열기
function openCameraUpload() {
    $('#cameraUploadDialog').slideDown('fast');
}

// 카메라 작업 창 닫기
function closeCameraUpload() {
    $('#cameraUploadDialog').slideUp('fast');
}

// 새폴더 생성 화면
function newFolder() {
	$('#explorerForm').css('display', 'none');
	$('#newFolderForm').css('display', 'block');
}

// 새폴더 생성
function newFolderCreate() {
    createFlag = "true";
	newfoldername = $('#newFolderName').val();
	
	// 폴더명이 비었을 경우 
	if(newfoldername == "") {
		navigator.notification.alert(lang_alert_valid_folder_name, "", 'Explorer', 'OK');
		return;
	}

	// 폴더명을 입력하였을 경우
	if(nowPage == "server")
		newServerFolder(newfoldername);
	else if (nowPage == "local")
		newLocalFolder(newfoldername);

	newFolderCancel();
}

// 새폴더 취소
function newFolderCancel() {
	$('#newFolderName').val('');
	$('#explorerForm').css('display', 'block');
	$('#newFolderForm').css('display', 'none');
}

// 파일 복사
function f_copy() {
    copyFlag = "true";
	tmpAction = "copy";

	if(nowPage == "server") {
		tmpFrom = "server";
		checked_list = $("#explorerList input:checkbox:checked");

		tmpCheckedList = new Array();
		tmpCheckedListAttribute = new Array();
		for(i=0; i < checked_list.length; i++) {
			tmpCheckedList.push(checked_list[i].value);
			tmpCheckedListAttribute.push(checked_list[i].alt);	// size & type(folder/file)
		}

		saveFileServer = tmpFileServer;
		savePartition = tmpPartition;
		saveDiskType = tmpDiskType;
		saveOwner = tmpOwner;
		saveStartPath = tmpStartPath;
		saveUserPath = tmpUserPath;
		saveShareUser = tmpShareUser;
		saveShareOwner = tmpShareOwner;
		saveSharePath = tmpSharePath;
		
		getDriveList();
	} else if ( nowPage == "local" ) {
		tmpFrom = "local";
		checked_list = $("#localList input:checkbox:checked");

		tmpCheckedList = new Array();
		for(i=0; i< checked_list.length; i++) {
			tmpCheckedList.push( checked_list[i].value );
		}
		
		getLocalList();
	}
	
	work_mode();
    copyFlag = "false";
}

// 파일 잘라내기
function snip() {
    moveFlag = "true";
	tmpAction = "snip";
	if(nowPage == "server") {
		tmpFrom = "server";
		checked_list = $("#explorerList input:checkbox:checked");

		tmpCheckedList = new Array();
		tmpCheckedListAttribute = new Array();
		for(i=0; i < checked_list.length; i++) {
			tmpCheckedList.push(checked_list[i].value);
			tmpCheckedListAttribute.push(checked_list[i].alt);
		}

		saveFileServer = tmpFileServer;
		savePartition = tmpPartition;
		saveDiskType = tmpDiskType;
		saveOwner = tmpOwner;
		saveStartPath = tmpStartPath;
		saveUserPath = tmpUserPath;
		saveShareUser = tmpShareUser;
		saveShareOwner = tmpShareOwner;
		saveSharePath = tmpSharePath;
		
		getDriveList();
	} else if(nowPage == "local") {
		tmpFrom = "local";
		checked_list = $("#localList input:checkbox:checked");

		tmpCheckedList = new Array();
		for(i=0; i < checked_list.length; i++) {
			tmpCheckedList.push(checked_list[i].value);
		}
		
		getLocalList();
	}

	work_mode();
    moveFlag = "false";
}

// 복사/이동할 파일 붙이기
function paste() {
	if(tmpFrom == "server" && nowPage == "server") {
		if(tmpAction == "snip")	SeverMoveFile();
		else 					ServerCopyFile();
	} else if(tmpFrom == "server" && nowPage == "local") {
		if(tmpAction == "copy") {
			flag = "download";
			checkConnection("download");
		} else
			alert("Server에서 Local로 파일 이동은 불가능합니다.");
	} else if(tmpFrom == "local" && nowPage == "local") {
		if(tmpAction == "snip")	LocalMove();
		else					LocalCopy();
	} else if(tmpFrom == "local" && nowPage == "server") {
		if(tmpAction == "copy")
			checkConnection("upload");
		else
			alert("Server에서 Local로 파일 이동은 불가능합니다.");
	}
	
	single_mode();
}

// 파일 삭제
function deleteFile() {
	if(nowPage == "server") {
		checked_list = $("#explorerList input:checkbox:checked");
		navigator.notification.confirm(
				/* lang_alert_delete, */
				'삭제하시겠습니까?',
				ConfirmdeleteFile,
				'Explorer',
				'No,Yes'
		);
	} else if(nowPage == "local") {
		checked_list = $("#localList input:checkbox:checked");
		navigator.notification.confirm(
				/* lang_alert_delete, */
				'삭제하시겠습니까?',
				ConfirmdeleteFile,
				'Explorer',
				'No,Yes'
		);
	}
}

// 파일 삭제 승인
function ConfirmdeleteFile(value) {
	if(value == "2") {
		if(nowPage == "server") {
			ServerDeleteFile();
		} else {
            LocalDeleteFile();
        }
    }
}

// 파일명 변경 화면
function rename() {
	SetlocalStorage("nowFunction", "rename");

	if(nowPage == "server") {
		checked_list = $("#explorerList input:checkbox:checked");
		var tmpFilename = checked_list[0].value;
		extension = "";
		if(tmpFilename.lastIndexOf('.') != -1) {
			index = tmpFilename.lastIndexOf('.');
			extension = tmpFilename.substring(index + 1).toLowerCase();
			reNameTmpFile = tmpFilename.split("." + extension);
			$('#renameName').val(reNameTmpFile[0]);
			$('#renameExtension').val(extension);
		} else {
			$('#renameName').val(checked_list[0].value);
			extension = "";
	    }
	} else if(nowPage == "local") {
		checked_list = $("#localList input:checkbox:checked");
		var tmpFilePath= checked_list[0].value;
		var tmpFilename = tmpFilePath.substring(tmpFilePath.lastIndexOf("/")+1);
		extension = "";
		
		if(tmpFilename.lastIndexOf('.') != -1) {
			index= tmpFilename.lastIndexOf('.');
			extension= tmpFilename.substring(index+1).toLowerCase();
			// Server로부터 다운받아 암호화된 파일
			if(extension == "secure") {
				var split= tmpFilename.split('.');
				extension= split[split.length-2]+ "."+ split[split.length-1];
				extension= extension.toLowerCase();
				reNameTmpFile= tmpFilename.split("." + extension);
			}
			// 사용자에 의하여 생성된 파일
			else {
				reNameTmpFile = tmpFilename.split("." + extension);
			}
			$('#renameName').val(reNameTmpFile[0]);
			$('#renameExtension').val(extension);
		} else {
			$('#renameName').val(checked_list[0].value.substring(checked_list[0].value.lastIndexOf("/")+1));
			extension = "";
	    }
	}
	
	$('#explorerForm').css('display', 'none');
	$('#renameForm').css('display', 'block');
}

// 파일명 변경 취소
function renameCancel() {
	$('#renameName').val('');
	$('#renameExtension').val('');
	
	$('#explorerForm').css('display', 'block');
	$('#renameForm').css('display', 'none');
	
	single_mode();
}

// 파일명 변경
function renameChange() {
	filename = $('#renameName').val();
	extension = $('#renameExtension').val();

	if(extension != "") {
        filename = filename + "." + extension;
        $('#renameExtension').val('');
        extension = "";
	}
	
	if(nowPage == "server")
		ServerRename(filename);
	else if ( nowPage == "local" )
		LocalRename(filename);
}

// 좌측메뉴_서버문서함 여닫기
function serverDocumentBoxFunction() {
	serverDocumentBox= document.getElementById('serverDocumentBox');
	serverDocumentList= document.getElementById('serverDocumentList');
	var height= $(serverDocumentBox).height(); 
	
	if(serverDocumentList.style.display !== 'none') {
		serverDocumentList.style.display= 'none';
		serverDocumentBox.style.borderBottom= '2px solid #C6C6C6';
		serverDocumentBox.style.height= (height+2)+ 'px';
	}
	else {
		serverDocumentList.style.display= 'block';
		serverDocumentBox.style.borderBottom= '1px solid #C6C6C6';
		serverDocumentBox.style.height= (height+1)+ 'px';
	}
}

// 좌측메뉴_로컬문서함 여닫기
function localDocumentBoxFunction() {
	localDocumentList= document.getElementById('localDocumentList');
	
	if(localDocumentList.style.display !== 'none') {
		localDocumentList.style.display= 'none';
	}
	else {
		localDocumentList.style.display= 'block';
	}
}

//파일 다운로드 현황판 표시
function showUpDownProgressbar() {
	document.getElementById("IndicatorCurrent").style.width = "0px";
	document.getElementById("indicator").style.width = "0px";
	document.getElementById("ProgressnumCurrent").innerHTML = "0";
	document.getElementById("progressnum").innerHTML = "0";

	updown_progressbar = $('#updown_progressbar');
	SetlocalStorage("nowFunction", "progressbar");

	updown_progressbar.show();
}

// 파일 다운로드 현황판 숨김
function hiddenUpDownProgressbar() {
	$('#updown_progressbar').hide();
}

// 파일 다운로드 취소
function updowncancel() {
	hiddenUpDownProgressbar();
	updownmanager = new UpDownManager();	
	updownmanager.cancel("", "");	
}
