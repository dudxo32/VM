var nowPage = "";
var tmpCheckedList = new Array();
var tmpCheckedListAttribute = new Array();
var tmpAction = "";
var tmpWebServer = "";
var tmpDriveName = "";
var tmpFileServer = "";
var tmpFileServerPort = "";
var tmpPartition = "";
var tmpDiskType = "";
var paraDiskType = "";
var tmpOwner = "";
var tmpStartPath = "";
var tmpUserPath = "";
var tmpShareUser = "";
var tmpShareOwner = "";
var tmpSharePath = "";
var tmpSortFlag = "";
var tmpPermission = "";
var tmpTreeID = "";
var tmpLocalTreeID = "local_tree_0";
var tmpLocalRootPath = "";
var tmpLocalUserPath = "";
var tmpSubtree = "";
var tmpDomainID = GetlocalStorage("DomainID");
var tmpOrgCode = "0";
var tmpfilename = "";
var tmpfilesize = "";
var ECMFolder = "ECM/data";
var tmpAgent = "";
var saveFileServer = "";
var saveFileServerPort = "";
var savePartition = "";
var saveDiskType = "";
var saveOwner = "";
var saveStartPath = "";
var saveUserPath = "";
var saveShareUser = "";
var saveShareOwner = "";
var saveSharePath = "";
var saveParamVal = "";

var multipleFlag = "";
var copyFlag = "";
var moveFlag = "";

var downfile = 0;
var downfileoverwrite = 0;
var downfileoffset = 0;
var upfile = 0; 
var upfileoverwrite = 0;
var upfileoffset = 0;
var cameraFlag = "";
var checkwifi = false;

var lang_alert_delete = "";
//reg_device
var lang_alert_success_reg_device = "";
var lang_alert_needs_approval_reg_device = "";
var lang_alert_already_exist_reg_device = "";
var lang_alert_not_exist_user_reg_device = "";
var lang_alert_exceeds_number_reg_device = "";
var lang_alert_wrong_user_iofo_reg_device = "";
//login
var lang_alert_insert_server = "";
var lang_alert_insert_id = "";
var lang_alert_insert_password = "";
var lang_parameter_missing = "";
var lang_login_fail_create_home = "";
var lang_login_insert_info = "";
var lang_login_domain_disk_overflow = "";
var lang_login_stop_device = "";
var lang_login_lost_device = "";
var lang_login_not_exist_device = "";
var lang_index_simple_script_null_server = "";
var lang_server_error = "";
var lang_status_stop = "";
var lang_login_incorrect_password = "";
var lang_login_password_expire = "";
var lang_login_guest_expire = "";
var lang_login_not_allowed_agent = "";
var lang_exception_error = "";
var lang_ip_filtered = "";
var lang_server_busy = "";
var lang_user_busy = "";
var lang_access_denied = "";
var lang_invalid_parameter = "";
var lang_disk_overflow = "";
var lang_already_folder_exists = "";
var lang_already_file_error = "";
var lang_guest_root = "";
var lang_sharing_violation = "";
var lang_guest_data_root = "";
var lang_already_file_exists = "";
var lang_already_folder_error = "";
var lang_has_acl_folder = "";
var lang_has_share_folder = "";
var lang_substree_exists = "";
var lang_filename_filtered = "";
var lang_download_busy = "";
var lang_download_limit = "";
var lang_license_expired = "";
var lang_upload_limit = "";
var lang_upload_busy = "";
var lang_partial_success = "";
var lang_not_exists = "";
var lang_alert_not_exists_path = "";
var lang_alert_overwrite = "";
var lang_alert_offset = "";
var lang_alert_not_support_format = "";
var lang_confrim_wifi = "";
var lang_alert_not_exists_Officesuite = "";
var lang_confirm_CloseTheApp = "";
var lang_login_not_exists = "";

function getDriveList() {
    if(nowFunc == "multiple") {
        singleMode();
        nowFunc = "getDriveList";
    }
    $('#multipleBtnImg').css('display', 'none');
    
    nowPage = "server";

	User = GetsessionStorage("UserID");
	UserType= GetsessionStorage("LoginType");
	OSLang = GetlocalStorage("OSLang");
	if(OSLang == "kor") LangID = "0412";
	else if(OSLang == "chn") LangID = "0804";
	else if(OSLang == "jpn") LangID = "0411";
	else LangID = "0409";

	parameter = User + "\t" + UserType + "\t" + tmpDomainID + "\t" + LangID;
	cryptutil = new CryptUtil();
	cryptutil.call(SuccessGetDriveList, "", parameter, GetlocalStorage("SiteID"));
}

function SuccessGetDriveList(r) {
    if(multipleFlag == "true" && copyFlag != "true" && moveFlag != "true"){
        single_mode();
        multipleFlag = "false";
    }
	protocol = GetlocalStorage("protocol");
	server = GetlocalStorage("webserver");
	port = GetlocalStorage("port");
	tmpWebServer = server;
	RetArr = new Array();
	RetArr = r.split("\t");

	tmpparaData = "User=" + RetArr[0] + ";UserType=" + RetArr[1];
	tmpCookie = "DomainID="+ RetArr[2] + ";LangID="+ RetArr[3];
	paraData = "Server="+server+"&Port="+port+"&Url="+"/clientsvc/GetDriveList.jsp"+"&CookieData="+tmpCookie+"&ParamData="+tmpparaData;
    
    useProxy = GetlocalStorage("useProxy");
    if(useProxy == "true"){
        us = new ProxyConnect();
        us.proxyconn(SuccessDrive, function(){alert('fail');}, protocol, port, server, "POST", "/webapp/protocal_mgmt.jsp", paraData);
    } else {
        RetVal = AjaxRequest(protocol, port, server, "POST", "/webapp/protocal_mgmt.jsp", paraData);
        reciveGetDriveList(RetVal);
    }
    /*
    AM = new AppManager();
    AM.auth_check(check_GetDrive,null);
     */
}

function check_GetDrive(){
    useProxy = GetlocalStorage("useProxy");
    if(useProxy == "true"){
        us = new ProxyConnect();
        us.proxyconn(SuccessDrive, function(){alert('fail');}, protocol, port, server, "POST", "/webapp/protocal_mgmt.jsp", paraData);
    } else {
        RetVal = AjaxRequest(protocol, port, server, "POST", "/webapp/protocal_mgmt.jsp", paraData);
        reciveGetDriveList(RetVal);
    }
}

function SuccessDrive(RetVal){
    reciveGetDriveList(RetVal);
}

function reciveGetDriveList(data) {
	tmpUserPath = "";
	$('#explorer_lang_title').text(explorer_lang_title_server);
	$('#work_lang_title').text(explorer_lang_title_server);
	$("#currentFolder").text("Server");
	$('#explorerList li').remove();

	result = data.substring((data.indexOf("\r\n")) + 2);

    if("Success" != result.substring(0, 7))
		navigator.notification.alert("Get Drive list ERR: "+ result, null, 'Explorer', 'OK');
	contents = result.substring((result.indexOf("\r\n")) + 2);
	contents_split = contents.split("\r\n");

	// 좌측 메뉴 서버문서함 리스트 높이 조정
	serverDocumentListHeight= $(window).height() * contents_split.length * 7 / 80;
	if(serverDocumentListHeight >= $(window).height() * 0.48125)
		serverDocumentListHeight= $(window).height() * 0.48125;
	document.getElementById('serverDocumentList').style.height= serverDocumentListHeight+ 'px';
	
	for(i = 0; i<contents_split.length ; i++) {
		drive_info = contents_split[i].split("\t");
		SetsessionStorage(drive_info[2], drive_info[0]);
		treeid = drive_info[0]+"_"+i;
		
		$('#explorerList').append("<li class='drive'><div id='drive_image' onclick=\"downFolerDrive('"+treeid+"' , '"+drive_info[0]+"', '"+drive_info[2]+"', '"+drive_info[4]+"', '"+drive_info[5]+"', '"+drive_info[6]+"', '"+drive_info[9]+"','"+drive_info[7]+"','"+"no"+"')\"><img src='img/server.png'><span></span></div><div id='drive_info' onclick=\"downFolerDrive('"+treeid+"' , '"+drive_info[0]+"', '"+drive_info[2]+"', '"+drive_info[4]+"', '"+drive_info[5]+"', '"+drive_info[6]+"', '"+drive_info[9]+"','"+drive_info[7]+"','"+"no"+"')\"><div id='drive_info_name'>"+ drive_info[0]+ "</div><span></span></div></li>");
		$('#menu_explorerList').append("<li class='menu_explorer_li' onclick=\"menuDownFolerDrive('"+treeid+"' , '"+drive_info[0]+"', '"+drive_info[2]+"', '"+drive_info[4]+"', '"+drive_info[5]+"', '"+drive_info[6]+"', '"+drive_info[9]+"','"+drive_info[7]+"','"+"no"+"')\">"+ drive_info[0]+ "<span></span></li>");
	}

	$('.menu_explorer_li').css('height', $(window).height() * 7 / 80);

	singleModeOff();
}
