// 드라이브 들어가기
function downFolerDrive(treeid, drivename, owner, server, partiton, startpath, disktype, orgcode, subtree) {
    $('#multipleBtnImg').css('display', 'block');

    $("#currentFolder").text(drivename);

    tmpTreeID = treeid;
	tmpDriveName = drivename;
	tmpOwner = owner;
	tmpFileServer = server;
	tmpPartition = partiton;
	tmpStartPath = startpath;
	tmpUserPath = "/";
	tmpSubtree = subtree;
	User = GetsessionStorage("UserID");	
	Agent = GetlocalStorage("Platform");
	para = tmpUserPath + "\t" + tmpSubtree;
	paraDiskType = disktype;
	saveParamVal = disktype + "\t" + orgcode;
	saveParam = "saveParam" + owner;
	SetsessionStorage(saveParam, saveParamVal);	
	option = "";
	//
	loginType= GetsessionStorage("LoginType");
	/* 기존 option값 지정 source-code(2016.02.26 수정)
	 * disktype이 server에서 "personal"로만 내려오기에
	 * 기준값을 disktype이 아닌, LoginType으로 수정
	if(paraDiskType == "personal") option = "0x01";*/
	if(loginType == "Normal")	option = "0x01";
	else if(loginType == "GuestID")	option = "0x03";
	
	if(disktype == "share") {
		tmpStartPath = "/";
		para = "/\tno";
		tmpDiskType = "OrgCoworkShare";
        tmpShareUser = "";
        tmpSharePath = "";
        tmpShareOwner = "";
	}
	else
		tmpDiskType = "OrgCowork";
	
	cookie = tmpDomainID + "\t" + tmpDiskType + "\t" + User + "\t" + tmpPartition + "\t" + tmpWebServer + "\t" + Agent + "\t" + option + "\t" + tmpOwner + "\t" + tmpShareUser + "\t" + tmpShareOwner + "\t" + tmpStartPath;
	parameter = para + "\t" + cookie;
//  parameter = / no 1000000000000 OrgCowork asdf1 c_home 192.168.1.185 12 0x0100000 /asdf1(asdf1)
	
    
	cryptutil = new CryptUtil();
	cryptutil.call(SuccessGetList, "", parameter, GetlocalStorage("SiteID"));
}

function menuDownFolerDrive(treeid, drivename, owner, server, partiton, startpath, disktype, orgcode, subtree) {
	nowPage= "server";
	tmpUserPath = "";
	$('#explorer_lang_title').text(explorer_lang_title_server);
	$('#work_lang_title').text(explorer_lang_title_server);
	$("#currentFolder").text("Server");
	$('#explorerList li').remove();

    closeMenu();
	change_to_server_form();
	downFolerDrive(treeid, drivename, owner, server, partiton, startpath, disktype, orgcode, subtree);
}

// Server내 하위폴더 이동
function downFolder(treeid, foldername, owner, server, partiton, startpath, userpath, disktype, shareuser, sharepath){    
	tmpTreeID = treeid;
    
	tmpFileServer = server;
	tmpPartition = partiton;
	tmpDiskType = disktype;
	tmpOwner = owner;
	tmpStartPath = startpath;
	tmpUserPath = (userpath+"/"+foldername).replace("//", "/");	
    tmpShareUser = shareuser;
    tmpShareOwner = sharepath;

	para = tmpUserPath + "\t" + tmpSubtree;
	Agent = GetlocalStorage("Platform");
	option = "";
	if(paraDiskType == "personal") option = "0x01";
	
	if(disktype == "OrgCoworkShare"){
		tmpDiskType = "OrgCoworkShare";
	}
	else
		tmpDiskType = "OrgCowork";
	
	cookie = tmpDomainID + "\t" + tmpDiskType + "\t" + User + "\t" + tmpPartition + "\t" + tmpWebServer + "\t" + 
	Agent + "\t" + option + "\t" + tmpOwner + "\t" + tmpShareUser + "\t" + tmpShareOwner + "\t" + tmpStartPath;
	parameter = para + "\t" + cookie;

	cryptutil = new CryptUtil();
	cryptutil.call(function(r){SuccessGetList(r)}, "", parameter, GetlocalStorage("SiteID"));	 
}

// Server내 상위폴더 이동
function upFolder() {
    if(multipleFlag == "true" && copyFlag != "true" && moveFlag != "true"){
        single_mode();
        multipleFlag = "false";
    }
	if(tmpTreeID == "server_tree")	return;
	tmpTreeID = tmpTreeID.substring(0, (tmpTreeID.lastIndexOf("_")));

	tmpUserPath = tmpUserPath.substring(0, (tmpUserPath.lastIndexOf("/")));
	if(tmpUserPath == "")	tmpUserPath = "/";

	para = tmpUserPath + "\t" + tmpSubtree;
	Agent = GetlocalStorage("Platform");
	option = "";
	/* 기존 option값 지정 source-code(2016.02.26 수정)
	 * disktype이 server에서 "personal"로만 내려오기에
	 * 기준값을 disktype이 아닌, LoginType으로 수정
	if(paraDiskType == "personal") option = "0x01";*/
	if(loginType == "Normal")	option = "0x01";
	else if(loginType == "GuestID")	option = "0x03";

	cookie = tmpDomainID + "\t" + tmpDiskType + "\t" + User + "\t" + tmpPartition + "\t" + tmpWebServer + "\t"
			+ Agent + "\t" + option + "\t" + tmpOwner + "\t" + tmpShareUser + "\t" + tmpShareOwner + "\t" + tmpStartPath;
	parameter = para + "\t" + cookie;

	cryptutil = new CryptUtil();
	cryptutil.call(function(r){SuccessGetList(r)}, "", parameter, GetlocalStorage("SiteID"));
}

// Server 파일 재정리
function refresh() {
	para = tmpUserPath + "\t" + tmpSubtree;
	Agent = GetlocalStorage("Platform");
	option = "";
	if(paraDiskType == "personal") option = "0x01";
	cookie = tmpDomainID + "\t" + tmpDiskType + "\t" + User + "\t" + tmpPartition + "\t" + tmpWebServer + "\t"
			+ Agent + "\t" + option + "\t" + tmpOwner + "\t" + tmpShareUser + "\t" + tmpShareOwner + "\t" + tmpStartPath;
	parameter = para + "\t" + cookie;
    
	cryptutil = new CryptUtil();
    cryptutil.call(SuccessGetList, function(){alert('fail');}, parameter, GetlocalStorage("SiteID"));
    
    single_mode();
}

// 서버로부터 암호화된 정보를 사용하여 파일목록 가져오기
function SuccessGetList(r) {
	protocol = GetlocalStorage("protocol");
	port = GetlocalStorage("port");	 
	server = GetlocalStorage("webserver");

	RetArr = new Array(); 
	RetArr = r.split("\t");
	  
	tmpparaData = "SrcName=" + RetArr[0] + ";Subtree=" + RetArr[1];		 
	tmpCookie = "DomainID="+ RetArr[2] + ";DiskType="+ RetArr[3] + ";User="+ RetArr[4] + ";Partition="+ RetArr[5] + ";WebServer="+ RetArr[6] + ";Agent="+ RetArr[7] + ";Option="+ RetArr[8] + ";Cowork="+ RetArr[9] + ";ShareUser="+ RetArr[10] + ";SharePath="+ RetArr[11] + ";StartPath="+ RetArr[12] + ";RealIP="+ RetArr[13];

	paraData = "Server="+tmpFileServer+"&Port="+port+"&Url="+"/PlusDrive/GetList"+"&CookieData="+tmpCookie+"&ParamData="+tmpparaData;

    useProxy = GetlocalStorage("useProxy");
    if(useProxy == "true"){
        us = new ProxyConnect();
        us.proxyconn(reciveGetList, function(){alert('fail');}, protocol, port, server, "POST", "/webapp/protocal_mgmt.jsp", paraData);
    } else {
        RetVal = AjaxRequest(protocol, port, server, "POST", "/webapp/protocal_mgmt.jsp", paraData);
        reciveGetList(RetVal,paraData);
    }
}

// 서버로부터 가져온 파일목록 나타내기
function reciveGetList(data) {
    
	/* data=
	 * version 1.0
	 * Success
	 * rwdklceps
	 * asdf.Show 30010rdep 0
	 * 2015-11-09 16:12:01
	 * 반출문서.docx 12958rdep 0
	 * 2015-11-06 13:02:41
	 * 새 텍스트 문서.html 9831 rdep 0
	 * 2015-11-06 13:03:00
	 * ...
	 * */
	result = data.substring((data.indexOf("\r\n"))+2);
	if("Success" != result.substring(0, 7))
		alertMessage(result);

	$('#explorerList li').remove();

	contents = result.substring((result.indexOf("\r\n"))+2);
	list = contents.substring(contents.indexOf("\r\n")).split("\r\n");
	currentFolder = tmpUserPath.substring(tmpUserPath.lastIndexOf("/")+1);
	list.sort();
	if(currentFolder == "") {
		if(GetlocalStorage("SiteID") != "SUNGJOO") {
			$("#currentFolder").text(GetsessionStorage(tmpOwner));
		} else {
			$("#currentFolder").text("");
		}
	}
	else
		$("#currentFolder").text(currentFolder);
     
	File = 0x20;
	OrgFolder = 0x00000100;

	if(list[0] == "") {
		if(tmpDiskType == "OrgCoworkShare") {
			if(tmpShareUser == "" && tmpSharePath == "") {
				for(i=0; i< list.length ; i++) {
					list_info = list[i].split("\t");
                    
					tmpOwner = list_info[6];
					tmpFileServer = list_info[8];
					tmpPartition = list_info[9];
					tmpShareUser = list_info[7];

					if((parseInt(list_info[3]) & File) != 0 && (parseInt(list_info[3]) & OrgFolder) == 0) {
						treeid = tmpTreeID+"_"+i;
						
						$('#explorerList').append("<li class='folder'><div id='file_image' onclick=\"downFolder('"+treeid+"', '"+list_info[0]+"', '"+list_info[6]+"', '"+list_info[8]+"', '"+list_info[9]+"', '"+tmpStartPath+"', '"+tmpUserPath+"', '"+tmpDiskType+"', '"+list_info[7]+"', '"+tmpSharePath+"')\"><img src='img/folder.png'></div><div id='file_info' onclick=\"downFolder('"+treeid+"', '"+list_info[0]+"', '"+list_info[6]+"', '"+list_info[8]+"', '"+list_info[9]+"', '"+tmpStartPath+"', '"+tmpUserPath+"', '"+tmpDiskType+"', '"+list_info[7]+"', '"+tmpSharePath+"')\"><div id='file_info_name'>"+ list_info[0]+ "</div><div id='file_info_date'>"+ list_info[4]+ "</div></div><div class='file_func'><a href='#fileFuncModal' onclick=\"openFileFuncDialog('"+ list_info[0]+ "')\"><img src='img/function.png'></a></div><div class='file_select'><input type='checkbox' id='"+list_info[0] +"' class='button-settings' value='"+list_info[0]+"' alt='"+list_info[3]+"\t"+list_info[1]+"'/><label for='"+list_info[0] +"' onclick=\"li_select('"+ list_info[0]+"')\"></label></div><div class='file_noneFunc'></div></li>");
						/*$("#server_list").append("<li class='folderlist'><input type='checkbox' class='abs listcheckbox' value='"+list_info[0]+"' alt='"+list_info[3]+"\t"+list_info[1]+"'/><img src='./img/folder/folder01.png' class='abs folderimg'><div class='folderclick'  ><span onclick=\"downFolder('"+treeid+"', '"+list_info[0]+"', '"+list_info[6]+"', '"+list_info[8]+"', '"+list_info[9]+"', '"+tmpStartPath+"', '"+tmpUserPath+"', '"+tmpDiskType+"', '"+list_info[7]+"', '"+tmpSharePath+"')\" > "+list_info[0]+"</span><br><span class='subinfo'>"+list_info[4]+"</span></div></li>");
						$("#"+tmpTreeID).append("<li id='"+treeid+"'><span onclick=\"downFolder('"+treeid+"', '"+list_info[0]+"', '"+list_info[6]+"', '"+list_info[8]+"', '"+list_info[9]+"', '"+tmpStartPath+"', '"+tmpUserPath+"', '"+tmpDiskType+"', '"+list_info[7]+"', '"+tmpSharePath+"')\">"+list_info[0]+"</span></li>");*/
					}
				}

				for(i=0; i< list.length ; i++) {
					list_info = list[i].split("\t");
					
					if((parseInt(list_info[3]) & File) == 0 && ""!=list_info[0]) {
						xfile = list_info[0].substring(list_info[0].lastIndexOf(".") + 1);
						xfile = xfile.toLowerCase();
						xfile = get_fileicon(xfile);
						xfileimg = "img/icon/" + xfile + ".png";
						
						$('#explorerList').append("<li class='file'><div id='file_image' onclick=\"getFile('"+list_info[0]+"', '"+list_info[1]+"')\"><img src='"+ xfileimg+ "'></div><div id='file_info' onclick=\"getFile('"+list_info[0]+"', '"+list_info[1]+"')\"><div id='file_info_name'>"+ list_info[0]+ "</div><div id='file_info_date'>"+ list_info[4]+ "</div></div><div class='file_func'><a href='#fileFuncModal' onclick=\"openFileFuncDialog('"+ list_info[0]+ "')\"><img src='img/function.png'></a></div><div class='file_select'><input type='checkbox' id='"+list_info[0] +"' class='button-settings' value='"+list_info[0]+"' alt='"+list_info[3]+"\t"+list_info[1]+"'/><label for='"+list_info[0] +"' onclick=\"li_select('"+ list_info[0]+"')\"></label></div><div class='file_noneFunc'></div></li>");
						/*$("#server_list").append("<li class='filelist'><input type='checkbox' class='abs listcheckbox' value='"+list_info[0]+"' alt='"+list_info[3]+"\t"+list_info[1]+"'/><img src='./img/file/"+xfile+".png' class='abs fileimg'><div class='fileclick'  ><span onclick=\"getFile('"+list_info[0]+"', '"+list_info[1]+"')\" > "+list_info[0]+"</span><br><span class='subinfo'>"+byteConvertor(list_info[1])+", &nbsp;&nbsp;"+list_info[4]+"</span></li>");*/
					}
				}
			} else {
				for(i=0; i< list.length ; i++) {
					list_info = list[i].split("\t");
                    
                    
                    
					if(list_info[5] != null)
						tmpSharePath = list_info[5];
					if((parseInt(list_info[3]) & File) != 0 && (parseInt(list_info[3]) & OrgFolder) == 0) {
						treeid = tmpTreeID+"_"+i;
						
						$('#explorerList').append("<li class='folder'><div id='file_image' onclick=\"downFolder('"+treeid+"', '"+list_info[0]+"', '"+tmpOwner+"', '"+tmpFileServer+"', '"+tmpPartition+"', '"+tmpStartPath+"', '"+tmpUserPath+"', '"+tmpDiskType+"', '"+tmpShareUser+"', '"+tmpSharePath+"')\"><img src='img/folder.png'></div><div id='file_info' onclick=\"downFolder('"+treeid+"', '"+list_info[0]+"', '"+tmpOwner+"', '"+tmpFileServer+"', '"+tmpPartition+"', '"+tmpStartPath+"', '"+tmpUserPath+"', '"+tmpDiskType+"', '"+tmpShareUser+"', '"+tmpSharePath+"')\"><div id='file_info_name'>"+ list_info[0]+ "</div><div id='file_info_date'>"+ list_info[4]+ "</div></div><div class='file_func'><a href='#fileFuncModal' onclick=\"openFileFuncDialog('"+ list_info[0]+ "')\"><img src='img/function.png'></a></div><div class='file_select'><input type='checkbox' id='"+list_info[0] +"' class='button-settings' value='"+list_info[0]+"' alt='"+list_info[3]+"\t"+list_info[1]+"'/><label for='"+list_info[0] +"' onclick=\"li_select('"+ list_info[0]+"')\"></label></div><div class='file_noneFunc'></div></li>");
						/*$("#server_list").append("<li class='folderlist'><input type='checkbox' class='abs listcheckbox' value='"+list_info[0]+"' alt='"+list_info[3]+"\t"+list_info[1]+"'/><img src='./img/folder/folder01.png' class='abs folderimg'><div class='folderclick'  ><span onclick=\"downFolder('"+treeid+"', '"+list_info[0]+"', '"+tmpOwner+"', '"+tmpFileServer+"', '"+tmpPartition+"', '"+tmpStartPath+"', '"+tmpUserPath+"', '"+tmpDiskType+"', '"+tmpShareUser+"', '"+tmpSharePath+"')\" > "+list_info[0]+"</span><br><span class='subinfo'>"+list_info[4]+"</span></div></li>");
						$("#"+tmpTreeID).append("<li id='"+treeid+"'><span onclick=\"downFolder('"+treeid+"', '"+list_info[0]+"', '"+tmpOwner+"', '"+tmpFileServer+"', '"+tmpPartition+"', '"+tmpStartPath+"', '"+tmpUserPath+"', '"+tmpDiskType+"', '"+tmpShareUser+"', '"+tmpSharePath+"')\">"+list_info[0]+"</span></li>");*/
					}
				}

				for(i=0; i< list.length ; i++) {
					list_info = list[i].split("\t");
                    
                    

					if((parseInt(list_info[3]) & File) == 0 && ""!=list_info[0]) {
						xfile = list_info[0].substring(list_info[0].lastIndexOf(".") + 1);
						xfile = xfile.toLowerCase();
						xfile = get_fileicon(xfile);
						xfileimg = "img/icon/" + xfile + ".png";
						
						$('#explorerList').append("<li class='file'><div id='file_image' onclick=\"getFile('"+list_info[0]+"', '"+list_info[1]+"')\"><img src='"+ xfileimg+ "'></div><div id='file_info' onclick=\"getFile('"+list_info[0]+"', '"+list_info[1]+"')\"><div id='file_info_name'>"+ list_info[0]+ "</div><div id='file_info_date'>"+ list_info[4]+ "</div></div><div class='file_func'><a href='#fileFuncModal' onclick=\"openFileFuncDialog('"+ list_info[0]+ "')\"><img src='img/function.png'></a></div><div class='file_select'><input type='checkbox' id='"+list_info[0] +"' class='button-settings' value='"+list_info[0]+"' alt='"+list_info[3]+"\t"+list_info[1]+"'/><label for='"+list_info[0] +"' onclick=\"li_select('"+ list_info[0]+"')\"></label></div><div class='file_noneFunc'></div></li>");
						/*$("#server_list").append("<li class='filelist'><input type='checkbox' class='abs listcheckbox' value='"+list_info[0]+"' alt='"+list_info[3]+"\t"+list_info[1]+"' title='"+list_info[1]+"'/><img src='./img/file/"+xfile+".png' class='abs fileimg'><div class='fileclick'  ><span onclick=\"getFile('"+list_info[0]+"', '"+list_info[1]+"')\" > "+list_info[0]+"</span><br><span class='subinfo'>"+byteConvertor(list_info[1])+", &nbsp;&nbsp;"+list_info[4]+"</span></li>");*/
					}
				}
			}
		} else {
			for(i=0; i< list.length ; i++) {
				list_info = list[i].split("\t");     

				if((parseInt(list_info[3]) & File) != 0 && (parseInt(list_info[3]) & OrgFolder) == 0) {
					treeid = tmpTreeID+"_"+i;
					$('#explorerList').append("<li class='folder'><div id='file_image' onclick=\"downFolder('"+treeid+"', '"+list_info[0]+"', '"+tmpOwner+"', '"+tmpFileServer+"', '"+tmpPartition+"', '"+tmpStartPath+"', '"+tmpUserPath+"', '"+tmpDiskType+"', '"+tmpShareUser+"', '"+tmpSharePath+"')\"><img src='img/folder.png'></div><div id='file_info' onclick=\"downFolder('"+treeid+"', '"+list_info[0]+"', '"+tmpOwner+"', '"+tmpFileServer+"', '"+tmpPartition+"', '"+tmpStartPath+"', '"+tmpUserPath+"', '"+tmpDiskType+"', '"+tmpShareUser+"', '"+tmpSharePath+"')\"><div id='file_info_name'>"+ list_info[0]+ "</div><div id='file_info_date'>"+ list_info[4]+ "</div></div><div class='file_func'><a href='#fileFuncModal' onclick=\"openFileFuncDialog('"+ list_info[0]+ "')\"><img src='img/function.png'></a></div><div class='file_select'><input type='checkbox' id='"+list_info[0] +"' class='button-settings' value='"+list_info[0]+"' alt='"+list_info[3]+"\t"+list_info[1]+"'/><label for='"+list_info[0] +"' onclick=\"li_select('"+ list_info[0]+"')\"></label></div><div class='file_noneFunc'></div></li>");
					/*$("#server_list").append("<li class='folderlist'><input type='checkbox' class='abs listcheckbox' value='"+list_info[0]+"' alt='"+list_info[3]+"\t"+list_info[1]+"'/><img src='./img/folder/folder01.png' class='abs folderimg'><div class='folderclick'  ><span onclick=\"downFolder('"+treeid+"', '"+list_info[0]+"', '"+tmpOwner+"', '"+tmpFileServer+"', '"+tmpPartition+"', '"+tmpStartPath+"', '"+tmpUserPath+"', '"+tmpDiskType+"', '"+tmpShareUser+"', '"+tmpSharePath+"')\" > "+list_info[0]+"</span><br><span class='subinfo'>"+list_info[4]+"</span></div></li>");
					$("#"+tmpTreeID).append("<li id='"+treeid+"'><span onclick=\"downFolder('"+treeid+"', '"+list_info[0]+"', '"+tmpOwner+"', '"+tmpFileServer+"', '"+tmpPartition+"', '"+tmpStartPath+"', '"+tmpUserPath+"', '"+tmpDiskType+"', '"+tmpShareUser+"', '"+tmpSharePath+"')\">"+list_info[0]+"</span></li>");*/
				}
			}

			for(i=0; i< list.length ; i++) {
				list_info = list[i].split("\t");
                
//                alert('list_info[2] = ' + list_info[2]);   // 파일 권한
                
				if((parseInt(list_info[3]) & File) == 0 && ""!=list_info[0]) {
					xfile = list_info[0].substring(list_info[0].lastIndexOf(".") + 1);
					xfile = xfile.toLowerCase();
					xfile = get_fileicon(xfile);
					xfileimg = "img/icon/" + xfile + ".png";

                    $('#explorerList').append("<li class='file'><div id='file_image' onclick=\"getFile('"+list_info[0]+"', '"+list_info[1]+"')\"><img src='"+ xfileimg+ "'></div><div id='file_info' onclick=\"getFile('"+list_info[0]+"', '"+list_info[1]+"', '"+list_info[2]+"')\"><div id='file_info_name'>"+ list_info[0]+ "</div><div id='file_info_date'>"+ list_info[4]+ "</div></div><div class='file_func'><a href='#fileFuncModal' onclick=\"openFileFuncDialog('"+ list_info[0]+ "')\"><img src='img/function.png'></a></div><div class='file_select'><input type='checkbox' id='"+list_info[0] +"' class='button-settings' value='"+list_info[0]+"' alt='"+list_info[3]+"\t"+list_info[1]+"'/><label for='"+list_info[0] +"' onclick=\"li_select('"+ list_info[0]+"')\"></label></div><div class='file_noneFunc'></div></li>");
					//$("#server_list").append("<li class='filelist'><input type='checkbox' class='abs listcheckbox' value='"+list_info[0]+"' alt='"+list_info[3]+"\t"+list_info[1]+"' title='"+list_info[1]+"'/><img src='./img/file/"+xfile+".png' class='abs fileimg'><div class='fileclick'  ><span onclick=\"getFile('"+list_info[0]+"', '"+list_info[1]+"')\" > "+list_info[0]+"</span><br><span class='subinfo'>"+byteConvertor(list_info[1])+", &nbsp;&nbsp;"+list_info[4]+"</span></li>");
				}
			}
		}
	}
	singleModeOn();
}

/* 파일 확장자에 따라 파일이미지 결정
 * reciveGetList() -> get_fileicon()
 */
function get_fileicon(xfilename) {

	var icon_array = ["ai", "ais", "alz", "arj", "asf", "asp", "avi", "bak","bat", "bmp", "cab", "cda", "com", "css", "doc",
	                  "docx", "dwg", "egg", "eml", "eps", "exe", "fla", "flv", "fmp", "fxg", "gif", "gz", "htm", "html", "hwp",
	                  "ico", "iff", "ini", "ink", "jas", "jpg", "js", "jsp", "k3g", "kmp", "md", "mid", "mka", "mkv", "mmf",
	                  "mov", "mp3", "mp4", "mpeg", "mpg", "ogg", "pak", "pcx", "pdd", "pdf", "pdp", "php", "pif", "png", "ppt",
	                  "pptx", "psd", "pxr", "ra", "rar", "raw", "s3m", "skm", "smi", "secure","swf", "tgz", "tif", "tp", "ts", "ttf", "txt",
	                  "vob", "wav", "wma", "wmv", "xls", "xlsx", "xml", "zip", "zool"];
	for(k=0 ; k< icon_array.length ; k++) {
		if(xfilename == icon_array[k]) return icon_array[k];
	}
	
	return "etc";
	
}

// Server 새폴더 생성
function newServerFolder(foldername) {
	createFolderPath = (tmpUserPath+"/"+foldername).replace("//", "/");
	Agent = GetlocalStorage("Platform");
	option = "";
	if(paraDiskType == "personal") option = "0x01";

	cookie = tmpDomainID + "\t" + tmpDiskType + "\t" + User + "\t" + tmpPartition + "\t" + tmpWebServer + "\t"
			+ Agent + "\t" + option + "\t" + tmpOwner + "\t" + tmpShareUser + "\t" + tmpShareOwner + "\t" + tmpStartPath;

	parameter = createFolderPath + "\t" + cookie;
	cryptutil = new CryptUtil();
	cryptutil.call(function(r){SuccessCreateDir(r)}, "", parameter, GetlocalStorage("SiteID"));
}

/* Server 새폴더 생성 진행
 * newServerFolder() -> SuccessCreateDir()
 */
function SuccessCreateDir(r) {
	protocol = GetlocalStorage("protocol");
	port = GetlocalStorage("port");
	server = GetlocalStorage("webserver");
	RetArr = new Array();
	RetArr = r.split("\t");
	
	tmpparaData = "SrcName=" + RetArr[0];	 
	tmpCookie = "DomainID="+ RetArr[1] + ";DiskType="+ RetArr[2] + ";User="+ RetArr[3] + ";Partition="+ RetArr[4]
		+ ";WebServer="+ RetArr[5] + ";Agent="+ RetArr[6] + ";Option="+ RetArr[7] + ";Cowork="+ RetArr[8]
		+ ";ShareUser="+ RetArr[9] + ";SharePath="+ RetArr[10] + ";StartPath="+ RetArr[11] + ";RealIP="+ RetArr[12];
	paraData = "Server=" + tmpFileServer + "&Port=" + port + "&Url=" + "/PlusDrive/CreateDir" + "&CookieData=" + tmpCookie + "&ParamData=" + tmpparaData;

    useProxy = GetlocalStorage("useProxy");
    if(useProxy == "true"){
        us = new ProxyConnect();
        us.proxyconn(completeCreateDir, function(){alert('fail');}, protocol, port, server, "POST", "/webapp/protocal_mgmt.jsp", paraData);
    } else {
        RetVal = AjaxRequest(protocol, port, server, "POST", "/webapp/protocal_mgmt.jsp", paraData);
        result = RetVal.substring((RetVal.indexOf("\r\n")) + 2);
        
        if("Success" != result.substring(0, 7))
            alertMessage(result);
        refresh();
        refresh();
    }
}

function completeCreateDir(RetVal){
    result = RetVal.substring((RetVal.indexOf("\r\n")) + 2);
    
    if("Success" != result.substring(0, 7))
        alertMessage(result);
    refresh();
    refresh();
}

// 서버 파일명 변경
function ServerRename(filename) {
	checked_list = $("#explorerList input:checkbox:checked");
	srcName = (tmpUserPath+"/"+checked_list[0].value).replace("//", "/");
	dstName = (tmpUserPath+"/"+filename).replace("//", "/");
	Agent = GetlocalStorage("Platform");
	option = "";
	if(paraDiskType == "personal") option = "0x01";

	cookie = tmpDomainID + "\t" + tmpDiskType + "\t" + User + "\t" + tmpPartition + "\t" + tmpWebServer + "\t"
		+ Agent + "\t" + option + "\t" + tmpOwner + "\t" + tmpShareUser + "\t" + tmpShareOwner + "\t" + tmpStartPath;

	parameter = srcName + "\t" + dstName + "\t" + cookie;

	cryptutil = new CryptUtil();
	cryptutil.call(function(r){SuccessRename(r)}, "", parameter, GetlocalStorage("SiteID"));
}

/* Server 파일명 변경 진행
 * ServerRename() -> SuccessRename()
 */
function SuccessRename(r) {
	protocol = GetlocalStorage("protocol");
	port = GetlocalStorage("port");
	server = GetlocalStorage("webserver");
	RetArr = new Array();
	RetArr = r.split("\t");

	tmpparaData = "SrcName=" + RetArr[0] + ";DstName=" + RetArr[1];
	tmpCookie = "DomainID="+ RetArr[2] + ";DiskType="+ RetArr[3] + ";User="+ RetArr[4] + ";Partition="+ RetArr[5]
		+ ";WebServer="+ RetArr[6] + ";Agent="+ RetArr[7] + ";Option="+ RetArr[8] + ";Cowork="+ RetArr[9]
		+ ";ShareUser="+ RetArr[10] + ";SharePath="+ RetArr[11] + ";StartPath="+ RetArr[12] + ";RealIP="+ RetArr[13];
	paraData = "Server="+tmpFileServer+"&Port="+port+"&Url="+"/PlusDrive/RenameFile"+"&CookieData="+tmpCookie+"&ParamData="+tmpparaData;

    useProxy = GetlocalStorage("useProxy");
    if(useProxy == "true"){
        us = new ProxyConnect();
        us.proxyconn(completeSuccessRename, function(){alert('fail');}, protocol, port, server, "POST", "/webapp/protocal_mgmt.jsp", paraData);
    } else {
        RetVal = AjaxRequest(protocol, port, server, "POST", "/webapp/protocal_mgmt.jsp", paraData);
        result = RetVal.substring((RetVal.indexOf("\r\n"))+2);
        
        if("Success" != result.substring(0, 7))
            alertMessage(result);
        closeRenameDialog();
        refresh();
        refresh();
    }
}

function completeSuccessRename(RetVal){
    result = RetVal.substring((RetVal.indexOf("\r\n"))+2);
    
    if("Success" != result.substring(0, 7))
        alertMessage(result);
    closeRenameDialog();
    refresh();
    refresh();
}

// Server 파일 삭제 준비
function ServerDeleteFile() {
	option = "";
	if(paraDiskType == "personal") option = "0x01";
	Agent = GetlocalStorage("Platform");
	cookie = tmpDomainID + "\t" + tmpDiskType + "\t" + User + "\t" + tmpPartition + "\t" + tmpWebServer + "\t"
		+ Agent + "\t" + option + "\t" + tmpOwner + "\t" + tmpShareUser + "\t" + tmpShareOwner + "\t" + tmpSharePath + "\t" + tmpStartPath;

	parameter = "";
	subtree = "yes";
	for(i=0; i < checked_list.length; i++) {
		if(i == 0)
			parameter = (tmpUserPath+"/"+checked_list[i].value).replace("//", "/");
		else
			parameter = parameter + "\t" + (tmpUserPath+"/"+checked_list[i].value).replace("//", "/");
	}
	parameter = parameter + "\t" + tmpFileServer + "\t" + subtree;
	parameter = parameter + "\t" + cookie;
	cryptutil = new CryptUtil();
	cryptutil.call(function(r){SuccessDeleteFile(r)}, "", parameter, GetlocalStorage("SiteID"));
}

/* Server 파일 삭제
 * ServerDeleteFile() -> SuccessDeleteFile()
 */
function SuccessDeleteFile(r) {
	protocol = GetlocalStorage("protocol");
	port = GetlocalStorage("port");
	server = GetlocalStorage("webserver");

	RetArr = new Array();
	RetArr = r.split("\t");
	chekecdLength = checked_list.length;

	tmpCheckedList = new Array(chekecdLength);
	for(i=0; i<chekecdLength; i++) {
		 tmpCheckedList[i] = RetArr[i];
	}
	chekecdLength = chekecdLength-1;

	idex = 1;
	tmpParam = ";FileServer=" + RetArr[chekecdLength+(idex++)] + ";Subtree=" + RetArr[chekecdLength+(idex++)];

	tmpCookie = "DomainID="+ RetArr[chekecdLength+(idex++)] + ";DiskType="+ RetArr[chekecdLength+(idex++)] + ";User="+ RetArr[chekecdLength+(idex++)] + ";Partition="+ RetArr[chekecdLength+(idex++)]
		+ ";WebServer="+ RetArr[chekecdLength+(idex++)] + ";Agent="+ RetArr[chekecdLength+(idex++)] + ";Option="+ RetArr[chekecdLength+(idex++)] + ";Cowork="+ RetArr[chekecdLength+(idex++)]
		+ ";ShareUser="+ RetArr[chekecdLength+(idex++)] + ";ShareOwner="+ RetArr[chekecdLength+(idex++)] + ";SharePath="+ RetArr[chekecdLength+(idex++)] + ";StartPath="+ RetArr[chekecdLength+(idex++)] + ";RealIP="+ RetArr[chekecdLength+(idex++)];

	DeleteProcess(tmpParam, tmpCookie);
}

/* Server 파일 삭제 진행
 * ServerDeleteFile() -> SuccessDeleteFile() -> DeleteProcess()
 */
function DeleteProcess(tmpParam ,tmpCookie) {
    port = GetlocalStorage("port");
    if(tmpCheckedList.length > 0) {
        tmpparaData = "SrcName=" + tmpCheckedList[0] + tmpParam;
        tmpCheckedList.splice(0, 1);
        paraData = "Server=" + tmpFileServer + "&Port=" + port + "&Url=" + "/PlusDrive/DeleteFile" + "&CookieData=" + tmpCookie + "&ParamData=" + tmpparaData;

        useProxy = GetlocalStorage("useProxy");
        if(useProxy == "true"){
            us = new ProxyConnect();
            us.proxyconn(completeSuccessRename, function(){alert('fail');}, protocol, port, server, "POST", "/webapp/protocal_mgmt.jsp", paraData);
        } else {
            RetVal = AjaxRequest(protocol, port, server, "POST", "/webapp/protocal_mgmt.jsp", paraData);
            result = RetVal.substring((RetVal.indexOf("\r\n"))+2);
            if("Success" != result.substring(0, 7))
                alertMessage(result);
            DeleteProcess(tmpParam, tmpCookie);
        }
        
    } else if(tmpCheckedList.length <= 0)
        refresh();
}


function completeDeleteProcess(RetVal){
    result = RetVal.substring((RetVal.indexOf("\r\n"))+2);
    
    if("Success" != result.substring(0, 7))
        alertMessage(result);
    DeleteProcess(tmpParam, tmpCookie);

}
// Server에서 Server로 파일 붙이기 준비
function ServerCopyFile() {
	for(i=0; i < checked_list.length; i++) {
		if(i == 0)	parameter = (saveUserPath+"/"+checked_list[i].value).replace("//", "/");
		else		parameter = parameter + "\t" + (saveUserPath+"/"+checked_list[i].value).replace("//", "/");
		// 작업 원본폴더와 대상폴더가 같은 경우 작업 취소
		samePath= saveUserPath+ checked_list[i].value;
		if(samePath == tmpUserPath) {
			navigator.notification.alert(lang_alert_same_dir, null, 'Server', 'OK');
			return;
		}
	}
    
	parameter = parameter + "\t" + tmpUserPath;
	logintype = GetsessionStorage("LoginType");

	dstOption = "0x00";
	if(paraDiskType == "personal" && logintype == "Normal")	dstOption = "0x01";
	else if(paraDiskType == "personal" && logintype == "GuestID")	dstOption = "0x02";
	else if(paraDiskType == "orgcowork" && logintype == "GuestID")	dstOption = "0x04";
	else if(paraDiskType == "homepartition" && logintype == "Normal")	dstOption = "0x08";

	if(tmpOwner != saveOwner) {
		parameter = parameter + "\t" + tmpFileServer + "\t" + tmpOwner + "\t" + tmpPartition + "\t" + dstOption + "\t"
			+ tmpDiskType + "\t" + tmpStartPath + "\t" + User + "\t" + tmpSharePath + "\t" + tmpShareUser;
	}
	saveParam = "saveParam"+saveOwner;

	paraDataArr = GetsessionStorage(saveParam).split("\t");
	saveDiskType = paraDataArr[0];
	saveOrgCode = paraDataArr[1];

	savaOption = "0";
	if(saveDiskType == "personal" && logintype == "Normal")				savaOption = "0x01";
	else if(saveDiskType == "personal" && logintype == "GuestID")		savaOption = "0x02";
	else if(saveDiskType == "orgcowork" && logintype == "GuestID")		savaOption = "0x04";
	else if(saveDiskType == "homepartition" && logintype == "Normal")	savaOption = "0x08";
	
	Agent = GetlocalStorage("Platform");
	cookie = tmpDomainID + "\t" + tmpDiskType + "\t" + User + "\t" + savePartition + "\t" + tmpWebServer + "\t"
		+ Agent + "\t" + savaOption + "\t" + saveOwner + "\t" + saveShareUser + "\t" + saveShareOwner + "\t" + saveStartPath;

	parameter = parameter + "\t" + cookie;
    
	cryptutil = new CryptUtil();
	cryptutil.call(function(r){SuccessCopyFile(r)}, "", parameter, GetlocalStorage("SiteID"));

}

/* Server에서 Server로 파일 붙이기
 * ServerCopyFile() -> SuccessCopyFile()
 */
function SuccessCopyFile(r) {
	protocol = GetlocalStorage("protocol");
	port = GetlocalStorage("port");
	server = GetlocalStorage("webserver");

	RetArr = new Array();
	RetArr = r.split("\t");

	chekecdLength = checked_list.length;
	tmpCheckedList = new Array(chekecdLength);
	for(i=0; i<chekecdLength; i++) {
		tmpCheckedList[i] = RetArr[i];
	}
	chekecdLength = chekecdLength-1;

	idex = 1;
	if(tmpOwner != saveOwner) {
		tmpParam = ";DstName=" + RetArr[chekecdLength+(idex++)] + ";DstFileServer=" + RetArr[chekecdLength+(idex++)] +";DstCowork="+ RetArr[chekecdLength+(idex++)] + ";DstPartition=" + RetArr[chekecdLength+(idex++)] + ";DstOption=" + RetArr[chekecdLength+(idex++)]
			+ ";DstDiskType=" + RetArr[chekecdLength+(idex++)] + ";DstStartPath=" + RetArr[chekecdLength+(idex++)] + ";DstUser=" + RetArr[chekecdLength+(idex++)]
			+ ";DstSharePath=" + RetArr[chekecdLength+(idex++)] + ";DstShareUser=" + RetArr[chekecdLength+(idex++)];
	} else
		tmpParam = ";DstName=" + RetArr[chekecdLength+(idex++)];
	
	tmpCookie = "DomainID="+ RetArr[chekecdLength+(idex++)] + ";DiskType="+ RetArr[chekecdLength+(idex++)] + ";User="+ RetArr[chekecdLength+(idex++)] + ";Partition="+ RetArr[chekecdLength+(idex++)]
		+ ";WebServer="+ RetArr[chekecdLength+(idex++)] + ";Agent="+ RetArr[chekecdLength+(idex++)] + ";Option="+ RetArr[chekecdLength+(idex++)] + ";Cowork="+ RetArr[chekecdLength+(idex++)]
		+ ";ShareUser="+ RetArr[chekecdLength+(idex++)] + ";SharePath="+ RetArr[chekecdLength+(idex++)] + ";StartPath="+ RetArr[chekecdLength+(idex++)] + ";RealIP="+ RetArr[chekecdLength+(idex++)];

	CopyProcess(tmpParam, tmpCookie);
}

/* 복사작업 수행
 * ServerCopyFile() -> SuccessCopyFile() -> CopyProcess()
 */
function CopyProcess(tmpParam, tmpCookie) {
	port = GetlocalStorage("port");
	if(tmpCheckedList.length > 0) {
		tmpparaData = "SrcName=" + tmpCheckedList[0] + tmpParam;
		tmpCheckedList.splice(0,1);
		paraData = "Server="+saveFileServer+"&Port="+port+"&Url="+"/PlusDrive/CopyFile"+"&CookieData="+tmpCookie+"&ParamData="+tmpparaData;
        
        useProxy = GetlocalStorage("useProxy");
        if(useProxy == "true"){
            us = new ProxyConnect();
            
            us.proxyconn(function completeCopyProcess(RetVal){
                         result = RetVal.substring((RetVal.indexOf("\r\n"))+2);
                         
                         if("Success" != result.substring(0, 7)) {
                         if("Invalid Parameter" == result)
                         navigator.notification.alert(lang_alert_path_exists_err, null, 'Explorer', 'OK');
                         else
                         alertMessage(result);
                         }
                         CopyProcess(tmpParam, tmpCookie);
                         }, function(){alert('fail');}, protocol, port, server, "POST", "/webapp/protocal_mgmt.jsp", paraData);
        } else {
            RetVal = AjaxRequest(protocol, port, server, "POST", "/webapp/protocal_mgmt.jsp", paraData);
            result = RetVal.substring((RetVal.indexOf("\r\n"))+2);
            
            if("Success" != result.substring(0, 7)) {
                if("Invalid Parameter" == result)
                    navigator.notification.alert(lang_alert_path_exists_err, null, 'Explorer', 'OK');
                else
                    alertMessage(result);
            }
            CopyProcess(tmpParam, tmpCookie);
        }
        
    } else if(tmpCheckedList.length <= 0)
        refresh();
}

// Server에서 Server로 파일 이동 준비
function SeverMoveFile() {
	for(i= 0; i < checked_list.length; i++) {
		if(i == 0)	parameter = (saveUserPath+"/"+checked_list[i].value).replace("//", "/");
		else		parameter = parameter + "\t" + (saveUserPath+"/"+checked_list[i].value).replace("//", "/");
		// 작업 원본폴더와 대상폴더가 같은 경우 작업 취소
		samePath= saveUserPath+ checked_list[i].value;
		if(samePath == tmpUserPath) {
			navigator.notification.alert(lang_alert_same_dir, null, 'Server', 'OK');
			return;
		}
	}
	parameter = parameter + "\t" + tmpUserPath;
	dstOption = "";
	if(paraDiskType == "personal")	dstOption = "0x01";
	else dstOption = "";
	if(tmpOwner != saveOwner) {
		parameter = parameter + "\t" + tmpFileServer + "\t" + tmpOwner + "\t" + tmpPartition + "\t" + dstOption + "\t"
			+ tmpDiskType + "\t" + tmpStartPath + "\t" + User + "\t" + tmpSharePath + "\t" + tmpShareUser;
	}
	
	savaOption = "";
	if(paraDiskType == "personal")	savaOption = "0x01";
	else							savaOption = "";
	Agent = GetlocalStorage("Platform");
	cookie = tmpDomainID + "\t" + tmpDiskType + "\t" + User + "\t" + savePartition + "\t" + tmpWebServer + "\t"
		+ Agent + "\t" + savaOption + "\t" + saveOwner + "\t" + saveShareUser + "\t" + saveShareOwner + "\t" + saveStartPath;

	parameter = parameter + "\t" + cookie;

	cryptutil = new CryptUtil();
	cryptutil.call(function(r){SuccessMoveFile(r)}, "", parameter, GetlocalStorage("SiteID"));
}

/* Server에서 Server로 파일 이동
 * SeverMoveFile() -> SuccessMoveFile()
 */
function SuccessMoveFile(r) {
	protocol = GetlocalStorage("protocol");
	port = GetlocalStorage("port");
	server = GetlocalStorage("webserver");

	RetArr = new Array();
	RetArr = r.split("\t");

	chekecdLength = checked_list.length;
	tmpCheckedList = new Array(chekecdLength);
	for(i=0; i<chekecdLength; i++) {
		tmpCheckedList[i] = RetArr[i];
	}
	chekecdLength = chekecdLength-1;

	idex = 1;
	if(tmpOwner != saveOwner) {
		tmpParam = ";DstName=" + RetArr[chekecdLength+(idex++)] + ";DstFileServer=" + RetArr[chekecdLength+(idex++)] +";DstCowork="+ RetArr[chekecdLength+(idex++)] + ";DstPartition=" + RetArr[chekecdLength+(idex++)] + ";DstOption=" + RetArr[chekecdLength+(idex++)]
			+ ";DstDiskType=" + RetArr[chekecdLength+(idex++)] + ";DstStartPath=" + RetArr[chekecdLength+(idex++)] + ";DstUser=" + RetArr[chekecdLength+(idex++)]
			+ ";DstSharePath=" + RetArr[chekecdLength+(idex++)] + ";DstShareUser=" + RetArr[chekecdLength+(idex++)];
	} else
		tmpParam = ";DstName=" + RetArr[chekecdLength+(idex++)];

	tmpCookie = "DomainID="+ RetArr[chekecdLength+(idex++)] + ";DiskType="+ RetArr[chekecdLength+(idex++)] + ";User="+ RetArr[chekecdLength+(idex++)] + ";Partition="+ RetArr[chekecdLength+(idex++)]
			+ ";WebServer="+ RetArr[chekecdLength+(idex++)] + ";Agent="+ RetArr[chekecdLength+(idex++)] + ";Option="+ RetArr[chekecdLength+(idex++)] + ";Cowork="+ RetArr[chekecdLength+(idex++)]
			+ ";ShareUser="+ RetArr[chekecdLength+(idex++)] + ";SharePath="+ RetArr[chekecdLength+(idex++)] + ";StartPath="+ RetArr[chekecdLength+(idex++)] + ";RealIP="+ RetArr[chekecdLength+(idex++)];

	MoveProcess(tmpParam, tmpCookie);
}

/* 파일 이동 수행
 * SeverMoveFile() -> SuccessMoveFile() -> MoveProcess()
 */
function MoveProcess(tmpParam, tmpCookie) {
	port = GetlocalStorage("port");
	if(tmpCheckedList.length > 0) {
		tmpparaData = "SrcName=" + tmpCheckedList[0] + tmpParam;
		tmpCheckedList.splice(0,1);
		paraData = "Server="+saveFileServer+"&Port="+port+"&Url="+"/PlusDrive/MoveFile"+"&CookieData="+tmpCookie+"&ParamData="+tmpparaData;

        useProxy = GetlocalStorage("useProxy");
        if(useProxy == "true"){
            us = new ProxyConnect();
            us.proxyconn(function completeMoveProcess(RetVal){
                         result = RetVal.substring((RetVal.indexOf("\r\n"))+2);
                         
                         if("Success" != result.substring(0, 7)) {
                            if("Invalid Parameter" == result)
                                   navigator.notification.alert(lang_alert_path_exists_err, null, 'Explorer', 'OK');
                            else
                                   alertMessage(result);
                         }
                         MoveProcess(tmpParam,tmpCookie);
                         }, function(){alert('fail');}, protocol, port, server, "POST", "/webapp/protocal_mgmt.jsp", paraData);
        } else {
            RetVal = AjaxRequest(protocol, port, server, "POST", "/webapp/protocal_mgmt.jsp", paraData);
            result = RetVal.substring((RetVal.indexOf("\r\n"))+2);
                      
            if("Success" != result.substring(0, 7)) {
                if("Invalid Parameter" == result)
                      navigator.notification.alert(lang_alert_path_exists_err, null, 'Explorer', 'OK');
                else
                      alertMessage(result);
            }
            MoveProcess(tmpParam,tmpCookie);
        }

    } else if(tmpCheckedList.length <= 0) {
            refresh();
    }
}

// Local에서 Server로 파일 복사/이동 준비
function upload(overwrite, offset) {
	if(GetsessionStorage("tmpPicturePath") != null) {
		localpath= GetsessionStorage("tmpPicturePath");
		SetsessionStorage("tmpPicturePath", null);
	}
    /*
    token = tmpCheckedList[0].split("/");
    
    if(token[token.length-1])
        copypath = checked_list[0].value;
    else
        copypath = tmpLocalRootPath + tmpCheckedList[0].substring(11, checked_list[0].value.length);
    */
	
	if(overwrite == "" && offset == "") {
		localpath = "";
		
		for(var i = 0; i < tmpCheckedList.length; i++) {
            
            
            token = tmpCheckedList[0].split("/");
            
            if(i == 0){
                if(token[token.length-1])
                    localpath = tmpCheckedList[i];
                else
                    localpath = tmpLocalRootPath + tmpCheckedList[i].substring(11, tmpCheckedList[i].length);
            }
            else{
				localpath = localpath + "\t" + tmpCheckedList[i];
            }
		}

		length = tmpCheckedList.length;
		tmpCheckedList.splice(0,length);
	}
	
	Agent = GetlocalStorage("Platform");
	siteid = GetlocalStorage("SiteID");
	useSSL = GetlocalStorage("SSL");
	FileServerPort = "";
	
	if(useSSL == "yes")	FileServerPort = GetlocalStorage("FileSSlPort");
	else FileServerPort = GetlocalStorage("FileHttpPort");

	showUpDownProgressbar();
	upfile = setInterval(uploadprogress, 100);
    
    var token = localpath.split("/");
    
    if(token[token.length-1]){
        fullPath = tmpLocalRootPath+ECMFolder+ "/" + User + tmpLocalUserPath + "/" + token[token.length-1];
    } else {
        fullPath = tmpLocalRootPath+ECMFolder+ "/" + User + tmpLocalUserPath + "/" + token[token.length-2];
    }
    
	useProxy = GetlocalStorage("useProxy");
	updownmanager = new UpDownManager();
	updownmanager.upload(SuccessUpload, "", tmpDomainID, paraDiskType, User, tmpPartition, tmpWebServer, Agent, option, tmpOwner, tmpShareUser,
			tmpShareOwner, tmpStartPath, tmpOrgCode, tmpUserPath, tmpFileServer, useSSL,FileServerPort, siteid, localpath, overwrite, offset, useProxy, fullPath);
}

/* Local에서 Server로 파일 복사/이동
 * upload() -> SuccessUpload()
 */
function SuccessUpload(retval) {
	if(retval == "Notexistingpath") {
		navigator.notification.alert(
				lang_alert_not_exists_path,
				null,
				'Explorer',
				'OK'
		);
	} else if(retval == "overwrite") {
		navigator.notification.confirm(
				lang_alert_overwrite,
				ConfirmOverwrite,
				'Explorer',        
				'No,Yes'    
		);
	} else if(retval == "offset") {
		navigator.notification.confirm(
				lang_alert_offset,        
				confirmOffset,        
				'Explorer',        
				'No,Yes'    
		);
	} else if(retval != "complete") {
		navigator.notification.alert(
				retval,
				null,
				'Explorer',
				'OK'
		);
	}
	
	clearInterval(upfile);
	clearInterval(upfileoverwrite);
	clearInterval(upfileoffset);
	hiddenUpDownProgressbar();

	refresh();
}

/* 업로드 진행 상태
 * upload() -> uploadprogress()
 */
function uploadprogress() {
	tmpdeviceutil = new DeviceUtil();
	tmpdeviceutil.progress(getsize, "", "upload");
}

// Server로부터 파일 열기 준비
function getFile(filename, size, auth_check) {
	tmpfilename = filename;
	tmpfilesize = size;

    if(auth_check.indexOf('r') != -1){
        index = filename.lastIndexOf('.');
        extension = filename.substring(index + 1).toLowerCase();
        file_open = GetlocalStorage("file_open");
	
        if(file_open == "app") {
            window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, LocalRootPath, null);
        } else {
            if(extension == "mp4" || extension == "avi" || extension == "3gp" || extension == "mp3" || extension == "wma" || extension == "mov"
               || extension == "jpg" || extension == "gif" || extension == "png" || extension == "doc" || extension == "docx"
               || extension == "ppt" || extension == "pptx"  || extension == "xls" || extension == "xlsx" || extension == "txt"
               || extension == "pdf") {
                window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, LocalRootPath, null);
            } else {
                navigator.notification.alert(
                                             lang_alert_not_support_format,
                                             null,
                                             'Explorer',
                                             'OK'
                                             );
            }
        }
    } else {
        alert('권한이 없습니다.');
    }
    
    
}

/* 열을 파일 경로 확인 
 * getFile() -> LocalRootPath()
 */
function LocalRootPath(fileSystem) {
	var LocalRoot = fileSystem.root.name;

	if(LocalRoot != "sdcard") LocalRoot = "sdcard";

	srcName = (tmpUserPath+"/"+tmpfilename).replace("//", "/");
	tmpLocalRootPath = "/" + LocalRoot;
	checkConnection("fileopen");
}

/* Server파일 열기
 * getFile() -> LocalRootPath() -> fileopen()
 */
function fileopen(overwrite, offset) {
	tmpname = srcName.substring(srcName.lastIndexOf('/'));
	index = tmpname.lastIndexOf('.');
	extension = tmpname.substring(index + 1).toLowerCase();
    
    viewer = GetlocalStorage("Officesuite");
    file_open = GetlocalStorage("file_open");
    
    if( file_open != "app" ){   
    	if(extension == "doc" || extension == "docx" || extension == "ppt" || extension == "pptx"
    		|| extension == "xls" || extension == "xlsx" || extension == "txt" || extension == "pdf"){	
    		if( file_open == "viewer" && viewer == "nonexistent"  ){
    			//alert("not exist Officesuite");
    			alertMessage("not installed officesuite");
    			return;
    		}
    	}
    }
	    
	tmpLocalpath = tmpLocalRootPath +"/ECM";
	attribute = "0"; 
	siteid = GetlocalStorage("SiteID");
	option = "";
	Agent = GetlocalStorage("Platform");
	if(paraDiskType == "personal") option = "0x01";	 

	showUpDownProgressbar();
    downfile = setInterval(downloadprogress, 100);
		
	useSSL = GetlocalStorage("SSL");
	FileServerPort = "";		
	if(useSSL == "yes") FileServerPort = GetlocalStorage("FileSSlPort");  
	else FileServerPort = GetlocalStorage("FileHttpPort");		

    useProxy = GetlocalStorage("useProxy");
	updownmanager = new UpDownManager();
	updownmanager.download(SuccessFileOpen, failMsg, tmpDomainID, paraDiskType, User, tmpPartition, tmpWebServer, Agent, option, tmpOwner, tmpShareUser,
			tmpShareOwner, tmpStartPath, tmpOrgCode, srcName, tmpFileServer,useSSL,FileServerPort, "fileopen", siteid, attribute,tmpfilesize, tmpLocalpath, overwrite, offset, useProxy);
}

/* 파일 열어 보기
 * getFile() -> LocalRootPath() -> fileopen() -> SuccessFileOpen()
 */
function SuccessFileOpen(r) {
	clearInterval(downfile);
	hiddenUpDownProgressbar();
	
	if(r == "exists") {
		navigator.notification.alert(
				lang_already_folder_exists,
				null,
				'Explorer',
				'OK'
		);
	} else if(r == "Notexistingpath") {
		navigator.notification.alert(
				lang_alert_not_exists_path,
				null,
				'Explorer',
				'OK'
		);
	} else if(r == "Failed") {
		navigator.notification.alert(
				lang_alert_create_folder_fail,
				null,
				'Explorer',
				'OK'
		);
	} else if(r == "overwrite") {
		navigator.notification.confirm(
				lang_alert_overwrite,
				ConfirmFileOpenOverwrite,
				'Explorer',
				'No,Yes'
		);
	} else if(r == "offset") {
		/*navigator.notification.confirm(
				lang_alert_offset,
				confirmFileOpenOffset,
				'Explorer',
				'No,Yes'
		);*/
		confirmFileOpenOffset();
	} else if(r == "Canceled") {
		hiddenAll();
	} else if(r != "complete") {
		r = encodeURI(r);
		clearInterval(downfile);
		clearInterval(downfileoverwrite);
		clearInterval(downfileoffset);
		file_open = GetlocalStorage("file_open");
		if( file_open == "" || file_open == null ) file_open = "viewer";
//		webview = ChildBrowser.install();
//		window.plugins.childBrowser.showWebPage(r, file_open);
        window.open(r, "_blank", "location=no");
	} else {
		tmpLocalpath = tmpLocalRootPath +"/ECM/dcrypt_tmp/" + tmpfilename;
		openFile(tmpLocalpath, "Server");
	}
}

function FileURL(r){
    //tmpdeviceutil = new DeviceUtil();
    //tmpdeviceutil.alert(function(){},function(){},r);
    //alert(r);
	navigator.notification.alert(    
			r,    
			null,      		     
			'Login',            		    
			'OK'                  
			);
}

/* Upload()시 덮어쓰기
 * upload() -> SuccessUpload() -> ConfirmOverwrite()
 */
function ConfirmOverwrite(value) {
	clearInterval(upfile);
	hiddenUpDownProgressbar();
    if(value == "2") upload("yes", "no");
    else upload("no", "no");
}

function confirmOffset( value )
{    
	clearInterval(upfile);		
	hiddenUpDownProgressbar();
    if( value == "2" )
    {
        upload("no", "yes");
    }
    else
    {
        upload("no", "no");
    }
}

// 이미 존재하는 파일 열기
function ConfirmFileOpenOverwrite(value) {
    if(value == "2")
    	fileopen("yes", "no");
    else
    	fileopen("no", "no");
}

function confirmFileOpenOffset(value) {
	fileopen("no", "no");
}

/*
//Check 3G Upload
function CheckNetwork(){
	checkNetwork = new DeviceUtil();
	checkNetwork.Use3G(NetworkInfo,"");
}

function NetworkInfo(retVal){
	if(retVal == "no" || GetlocalStorage("Use3GUp") == "yes"){
		upload("","");
	}else{
		var bAnswer = confirm("3G�� ����� ������ ��ȭ�ᰡ �ΰ��� �� �ֽ��ϴ�."+<br>+"��� �Ͻðڽ��ϱ�?");
		if(bAnswer  == true)
			upload("","");
		else
			return;
	}
}

*/