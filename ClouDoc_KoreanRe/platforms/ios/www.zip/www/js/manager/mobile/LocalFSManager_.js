var fileSystemEntry = "";
var fileSystemRootPath = "";
var localRootPath = "";
var nowPath = "";

/* Local FileSystem 가져오기
 * 최상위 폴더 entry 반환
 */
function getLocalList() {
    window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, onSuccess, failMsg);
}

/* Local Drive 가져오기
 * getLocalList() -> onSuccess()
 */
function onSuccess(fileSystem) {
	fileSystemEntry = fileSystem.root;
	fileSystemRootPath = fileSystemEntry.nativeURL;
	setTimeout(function() {$('#explorer_lang_title').text(explorer_lang_title_local);}, 1);
	$('#work_lang_title').text(explorer_lang_title_local);
	$("#currentFolder").text("Local");
	nowPage = "local";
	
	fileSystemEntry.getDirectory("ECM", {create: true, exclusive: false}, function(dir) {
		dir.getDirectory("data", {create: true, exclusive: false}, function(dir) {
			localRootPath = dir.fullPath;
			downLocalFolder(localRootPath);
		}, failMsg);
	}, failMsg);
}

/*
 * 현재 위치의 폴더 목록 재구성
 */
function refreshLocalList() {
	fileSystemEntry.getDirectory(nowPath, {create: false}, function(dir){
		var directoryReader = dir.createReader();
		directoryReader.readEntries(successList, failMsg);
	}, failMsg);
}

// 로컬 목록 붙이기
var FolderNameArray = new Array();
var FolderPathArray = new Array();
function successList(entries) {
	$('#localList li').remove();
	
	if(nowPath == "/ECM/data/") {
		$("#currentFolder").text("Local");
	} else {
		$("#currentFolder").text((nowPath.substring(0, nowPath.length-1)).substring((nowPath.substring(0, nowPath.length-1)).lastIndexOf('/')+1));
	}

	var i;
	for(i=0; i<entries.length; i++) {
		if(entries[i].isDirectory) {
			FolderNameArray.push(entries[i].name);
			FolderPathArray.push(entries[i].fullPath);
			entries[i].getMetadata(successFolderList, failMsg);
		}
	}

	for(i=0; i<entries.length; i++) {
		if(!entries[i].isDirectory)	entries[i].file(successFileList, failMsg);
	}
}

/* Local 폴더 붙이기
 * successList() -> successFolderList()
 */
function successFolderList(mFolder) {
	if(FolderNameArray.length != 0) {
		var lastModTime = date_format(mFolder.modificationTime);
		var folderPath = FolderPathArray[0];
		var tmpFolderName = FolderNameArray[0];

		FolderNameArray.shift();
		FolderPathArray.shift();

		$('#localList').append("<li class='folder'><div id='folder_image' onclick=\"downLocalFolder('"+folderPath+"')\"><img src='img/folder.png'></div><div id='file_info' onclick=\"downLocalFolder('"+folderPath+"')\"><div id='file_info_name'>"+tmpFolderName+"</div><div id='file_info_date'>"+lastModTime+"</div></div><div class='file_func'><a href='#fileFuncModal' onclick=\"openFileFuncDialog('"+tmpFolderName+"')\"><img src='img/function.png'></a></div><div class='file_select'><input type='checkbox' id='"+tmpFolderName+"' class='button-settings' value='"+folderPath+"'/><label for='"+tmpFolderName+"' onclick=\"fileSelect('"+tmpFolderName+"')\"></label></div></li>");
    }
}

/* Local 파일 붙이기
 * successList() -> successFileList()
 */
function successFileList(file) {
	var lastModTime = date_format(new Date(file.lastModifiedDate));
	var filePath = nowPath + file.name;
	var xfile = file.name.substring(file.name.lastIndexOf(".")+1);
	var fileSize = size_format(file.size);
	xfile = xfile.toLowerCase();
	xfile = get_fileicon(xfile);
	xfileimg = "img/icon/" + xfile + ".png";
	
	$('#localList').append("<li class='file'><div id='file_image' onclick=\"openFile('"+filePath+"', '"+"Local"+"')\"><img src='"+xfileimg+"'></div><div id='file_info' onclick=\"openFile('"+filePath+"', 'Local')\"><div id='file_info_name'>"+file.name+"</div><div id='file_info_date'>"+lastModTime+"\t"+fileSize+"</div></div><div class='file_func'><a href='#fileFuncModal' onclick=\"openFileFuncDialog('"+file.name+"')\"><img src='img/function.png'></a></div><div class='file_select'><input type='checkbox' id='"+file.name+"' class='button-settings' value='"+filePath+"'/><label for='"+file.name+"' onclick=\"fileSelect('"+file.name+"')\"></label></div></li>");
}

/* 폴더/파일 날짜 형식 변경
 * successList() -> successFolderList()/successFileList() -> date_format()
 */
function date_format(mdate) {
	var d  = mdate.getDate();
	var day = (d < 10) ? '0' + d : d;
	var m = mdate.getMonth() + 1;
	var month = (m < 10) ? '0' + m : m;
	var yy = mdate.getYear();
	var year = (yy < 1000) ? yy + 1900 : yy;
	var hours = mdate.getHours();
	var m_mm = mdate.getMinutes();
	var minutes = (m_mm < 10) ? '0' + m_mm : m_mm;
	var msc = mdate.getSeconds();
	var seconds = (msc < 10) ? '0' + msc : msc;
	var dateFormat = year + "-" + month + "-" + day + " " + hours + ":" + minutes + ":"+seconds;
   
	return dateFormat;
}

/* 폴더/파일 크기 형식 변경
 * successList() -> successFolderList()/successFileList() -> size_format()
 */
function size_format(filesize) {
	if(filesize >= 1073741824) {
		filesize = number_format(filesize / 1073741824, 2, '.', '') + ' GB';
	} else {
		if(filesize >= 1048576) {
			filesize = number_format(filesize / 1048576, 2, '.', '') + ' MB';
		} else {
			if(filesize >= 1024) {
				filesize = number_format(filesize / 1024, 2, '.', '') + ' KB';
			} else {
				filesize = number_format(filesize, 2, '.', '') + ' bytes';
			};
		};
	};

	return filesize;
};

/* 폴더/파일 크기 구하기
 * successList() -> successFolderList()/successFileList() -> size_format() -> number_format()
 */
function number_format(number, decimals, dec_point, thousands_sep) {
	var n = number, c = isNaN(decimals = Math.abs(decimals)) ? 2 : decimals;
	var d = dec_point == undefined ? "," : dec_point;
	var t = thousands_sep == undefined ? "." : thousands_sep, s = n < 0 ? "-" : "";
	var i = parseInt(n = Math.abs(+n || 0).toFixed(c)) + "", j = (j = i.length) > 3 ? j % 3 : 0;

	return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
} 

// 로컬 폴더 내에서 하위폴더로 이동
function downLocalFolder(path) {
	$('#multipleBtnImg').css('display', 'block');
	nowPath = path;

	fileSystemEntry.getDirectory(path, {create: false}, function(dir) {
		var directoryReader = dir.createReader();
		directoryReader.readEntries(successList, failMsg);
	}, failMsg);
}

// 로컬 폴더 내에서 상위폴더로 이동
function upLocalFolder() {
	fileSystemEntry.getDirectory(nowPath, {create: false}, function(dir) {
		dir.getParent(function(dir){
			nowPath = dir.fullPath;
			var directoryReader = dir.createReader();
			directoryReader.readEntries(successList, failMsg);
		}, failMsg);
	}, failMsg);
}

// 로컬에서 새폴더 생성
function newLocalFolder(foldername) {
	var newFolderPath = nowPath + foldername;

	fileSystemEntry.getDirectory(newFolderPath, {create: true, exclusive: false}, refreshLocalList, failMsg);
}

// 로컬파일 및 폴더 삭제 준비
var localDeleteArray = new Array();
function LocalDeleteFile() {
	for(var index = 0; index < checked_list.length; index++) {
		localDeleteArray.push(checked_list[index].value); 
	}
	localDeleteProcess();

	singleMode();
}

/* LocalDeleteFile() -> localDeleteFileProcess()
 * Local 파일 및 폴더 삭제 진행
 */
function localDeleteProcess() {
	if(localDeleteArray.length > 0) {
		fileSystemEntry.getDirectory(localDeleteArray[0], {create: false}, function(dir) {
			dir.removeRecursively(function() {
				localDeleteArray.shift();
				localDeleteProcess();
			}, function(){});
		}, function() {
			fileSystemEntry.getFile(localDeleteArray[0], {create: false}, function(file) {
				file.remove(function() {
					localDeleteArray.shift();
					localDeleteProcess();
				}, function(){});
			}, function(){});
		});
	} else {
		refreshLocalList();
	}
}

// 로컬 폴더/파일 이름변경
function LocalRename(fileName) {
	fileSystemEntry.getDirectory(nowPath, {create: false}, function(parentDir) {
		fileSystemEntry.getDirectory(checked_list[0].value, {create: false}, function(dir) {
			dir.moveTo(parentDir, fileName, refreshLocalList, failMsg);
		}, fileSystemEntry.getFile(checked_list[0].value, {create: false}, function(file) {
			file.moveTo(parentDir, fileName, refreshLocalList, failMsg);
		}), failMsg);
	}, failMsg);
	
	closeRenameDialog();
}

// Local에서 Local로 파일 복사 준비
var localCopyArray = new Array();
function LocalCopy() {
	for(var index = 0; index < checked_list.length; index++) {
		if(checkCopyMove(checked_list[index].value))	localCopyArray.push(checked_list[index].value);
		else	return;
	}
	localCopyProcess();
}

/* LocalCopy() -> localCopyProcess()
 * Local에서 Local로 파일 복사 진행
 */
function localCopyProcess() {
	if(localCopyArray.length > 0) {
		var fileName = localCopyArray[0].substring(localCopyArray[0].lastIndexOf('/')+1);

		fileSystemEntry.getDirectory(nowPath, {create: false}, function(parentDir) {
			fileSystemEntry.getDirectory(localCopyArray[0], {create: false}, function(dir) {
				dir.copyTo(parentDir, fileName, function(){
					localCopyArray.shift();
					localCopyProcess();
				}, function(){});
			}, fileSystemEntry.getFile(localCopyArray[0], {create: false}, function(file) {
				file.copyTo(parentDir, fileName, function(){
					localCopyArray.shift();
					localCopyProcess();
				}, function(){});
			}), function(){});
		}, function(){});
	} else {
		refreshLocalList();
	}
}

// Local에서 Local로 파일 이동 준비
var localMoveArray = new Array();
function LocalMove() {
	for(var index = 0; index < checked_list.length; index++) {
		if(checkCopyMove(checked_list[index].value))	localMoveArray.push(checked_list[index].value);
		else	return;
	}
	localMoveProcess();
}

/* LocalMove() -> localMoveProcess()
 * Local에서 Local로 파일 이동 진행
 */
function localMoveProcess() {
	if(localMoveArray.length > 0) {
		var fileName = localMoveArray[0].substring(localMoveArray[0].lastIndexOf('/')+1);

		fileSystemEntry.getDirectory(nowPath, {create: false}, function(parentDir) {
			fileSystemEntry.getDirectory(localMoveArray[0], {create: false}, function(dir) {
				dir.moveTo(parentDir, fileName, function(){
					localMoveArray.shift();
					localMoveProcess();
				}, function(){});
			}, fileSystemEntry.getFile(localMoveArray[0], {create: false}, function(file) {
				file.moveTo(parentDir, fileName, function(){
					localMoveArray.shift();
					localMoveProcess();
				}, function(){});
			}), function(){});
		}, function(){});
	} else {
		refreshLocalList();
	}
}

// 복사/이동 전 확인
function checkCopyMove(target) {
	var parentNowPath = nowPath.substring(0, nowPath.lastIndexOf('/'));
	var parentTargetPath = "";
	if(target.lastIndexOf('/')+1 == target.length) {
		var targetPath = target.substring(0, target.lastIndexOf('/'));
		parentTargetPath = targetPath.substring(0, targetPath.lastIndexOf('/'));
	} else {
		parentTargetPath = target.substring(0, target.lastIndexOf('/'));
	}

	// 대상 폴더 안에 복사하려는 경우
	if(nowPath == target) {
		localCopyArray = new Array();
		navigator.notification.alert(lang_alert_same_dir+"2", function(){}, 'Local', 'OK');
		return false;
	}
	// 동일 위치에 복사하려는 경우
	if(parentNowPath == parentTargetPath) {
		localCopyArray = new Array();
		navigator.notification.alert(lang_alert_same_dir+"1", function(){}, 'Local', 'OK');
		return false;
	}
	return true;
}

//업/다운로드 진행시 네트워크 체크
function checkConnection(flag) {
	nowFlag = flag;
	AppManager.checkNetwork(function(netStatus) {
		if(netStatus == "wifi") {
			if(flag == "download")		download("", "");
			else if(flag == "fileopen")	fileopen("", "");
			else						upload("", "");
		}
		else if(netStatus == "mobile") {
			var useData = GetlocalStorage("useData");

			if(useData == "true") {
				if(flag == "download")		download("", "");
				else if(flag == "fileopen")	fileopen("", "");
				else						upload("", "");
			} else {
				navigator.notification.confirm(lang_confrim_wifi, confirmMobile, 'Explorer', ['No', 'Yes']);
			}
		}
		else {
			alert("Not connected with network.");
		}
	}, function(error){
		alert("Network check fail...\n" + error);
	});
}

// 모바일이 데이터망일 시, 사용자에게 선택
function confirmMobile(value) {
	if(value == "2") {
		if(nowFlag == "download") download("", "");
		else if(nowFlag == "fileopen")	fileopen("", "");
		else	upload("", "");
	}
}

/* checkConnection() -> download()
 * Server로부터 파일 다운로드
 */
function download(overwrite, offset) {
	// 동일명의 파일이 존재하는지 체크
	var existedFiles = new Array();
	fileSystemEntry.getDirectory(nowPath, {create: false}, function(dir){
		var reader = dir.createReader();
		reader.readEntries(function(entries){
			for(var index = 0; index<entries.length; index++) {
				var tmpName = "";
				if(entries[index].fullPath.lastIndexOf('/')+1 == entries[index].fullPath.length) {
					tmpName = entries[index].fullPath;
					tmpName = tmpName.substring(0, tmpName.lastIndexOf('/'));
					tmpName = tmpName.substring(tmpName.lastIndexOf('/')+1);
				} else {
					tmpName = entries[index].fullPath.substring(entries[index].fullPath.lastIndexOf('/')+1);
					if(tmpName.substring(tmpName.lastIndexOf('.')) == ".secure")	tmpName = tmpName.substring(0, tmpName.lastIndexOf('.'));
				}
				existedFiles.push(tmpName);
			}
			
			var targetFiles = new Array();
			for(var index = 0; index < tmpCheckedList.length; index++) {
				targetFiles.push(tmpCheckedList[index]);
			}
			
			for(var index1 = 0; index1 < existedFiles.length; index1++) {
				for(var index2 = 0; index2 < targetFiles.length; index2++) {
					if(targetFiles[index2] == existedFiles[index1]) {
						navigator.notification.alert('동일한 파일 존재합니다.', function(){}, 'Explorer', 'OK');
						return;
					}
				}
			}

			// 다운로드 작업 진행
			if(overwrite == "" && offset == "") {
				srcName = "";
				attribute = "";
				size = "";
				tmpAttributeArr = new Array();

				for(var i = 0; i < tmpCheckedList.length; i++) {
					if(i == 0) {
						srcName = (saveUserPath+"/"+tmpCheckedList[i]).replace("//", "/");
						tmpAttributeArr = tmpCheckedListAttribute[i].split("\t");
						attribute = tmpAttributeArr[0];
						size = tmpAttributeArr[1];
					} else {
						srcName =  srcName + "\t" + (saveUserPath+"/"+tmpCheckedList[i]).replace("//", "/");
						tmpAttributeArr = tmpCheckedListAttribute[i].split("\t");
						attribute = attribute + "\t" + tmpAttributeArr[0];
						size = size + "\t" + tmpAttributeArr[1];
					}
				}
			}

			siteid = GetlocalStorage("SiteID");
			option = "";
			if(paraDiskType == "personal")	option = "0x01";
			useSSL = GetlocalStorage("SSL");
			FileServerPort = "";
			if(useSSL == "yes")	FileServerPort = GetlocalStorage("FileSSlPort");
			else				FileServerPort = GetlocalStorage("FileHttpPort");
			Agent = GetlocalStorage("Platform");

			showUpDownProgressbar();
			downfile = setInterval(downloadprogress, 10);
			
			var destination = fileSystemRootPath + nowPath.substring(nowPath.indexOf('/')+1);
			if(destination.match("file://")) {
				destination = destination.substring(("file://").length);
			}

			UpDownManager.download(SuccessDownLoad, failMsg, tmpDomainID, paraDiskType, User, savePartition, tmpWebServer, Agent, option, saveOwner, saveShareUser,
					saveShareOwner, saveStartPath, tmpOrgCode, srcName, saveFileServer,useSSL, FileServerPort, "download", siteid, attribute, size, destination, overwrite, offset);
		}, function(){});
	}, function(){});
}

/* checkConnection() -> confirmMobile() -> download() -> SuccessDownLoad()
 * Server로부터 파일 다운로드 수행 결과
 */
function SuccessDownLoad(r) {
	if(r == "exists") {
		navigator.notification.alert(lang_already_folder_exists, function(){}, 'Explorer', 'OK');
	} else if(r == "Notexistingpath") {
		navigator.notification.alert(lang_alert_not_exists_path, function(){}, 'Explorer', 'OK');
	} else if(r == "Failed") {
		navigator.notification.alert(lang_alert_create_folder_fail, function(){}, 'Explorer', 'OK');
	} else if(r == "overwrite") {
		clearInterval(downfile);
		downfileoverwrite = setInterval(downloadprogress, 100);
		showUpDownProgressbar();
		navigator.notification.confirm(lang_alert_overwrite, ConfirmDownOverwrite, 'Explorer', ['No', 'Yes']);
	} else if(r == "offset") {
		clearInterval(downfile);
		downfileoffset = setInterval(downloadprogress, 100);
		showUpDownProgressbar();
		navigator.notification.confirm(lang_alert_offset, confirmDownOffset, 'Explorer', ['No', 'Yes']);
	} else if(r == "complete") {
		srcName = "";
		attribute = "";
	} else if(r != "complete") {
		navigator.notification.alert(r, function(){}, 'Explorer', 'OK');
	}
	
	refreshLocalList();
	tmpCheckedList = new Array();
	tmpCheckedListAttribute = new Array();
	clearInterval(downfile);
	clearInterval(downfileoverwrite);
	clearInterval(downfileoffset);
	hiddenUpDownProgressbar();
}

/* checkConnection() -> confirmMobile() -> download() -> SuccessDownLoad() -> downloadprogress()
 * 다운로드 진행상태
 */
function downloadprogress() {
	DeviceUtil.progress(getsize, "", "download");
}

/* checkConnection() -> confirmMobile() -> download() -> SuccessDownLoad() -> downloadprogress() -> getsize()
 * 다운로드 진행상태의 표시 파일크기
 */
function getsize(retval) {
	var ProgressnumCurrent = document.getElementById("ProgressnumCurrent");
	var IndicatorCurrent = document.getElementById("IndicatorCurrent");
	var progressnum = document.getElementById("progressnum");
	var indicator = document.getElementById("indicator");

	var SizeArr = new Array();
	SizeArr = retval.split("\t");
	var currentmaxprogress = SizeArr[0];
	var currentactualprogress = SizeArr[1] * ($('#ProgressbarCurrent').width()/currentmaxprogress);
	var maxprogress = SizeArr[2];
	var actualprogress = SizeArr[3] * ($('#progressbar').width()/maxprogress);
	IndicatorCurrent.style.width=currentactualprogress + "px";

	var nowsize = size_format(SizeArr[1]);
	var nowFilesize = size_format(SizeArr[0]);
	var totalnowsize = size_format(SizeArr[3]);
	var totalFilesize = size_format(SizeArr[2]);

	ProgressnumCurrent.innerHTML = nowsize+"\t"+"/"+"\t"+nowFilesize;
	indicator.style.width=actualprogress + "px";
	progressnum.innerHTML = totalnowsize+"\t"+"/"+"\t"+totalFilesize;
}

// Local File 열기
function openFile(filepath, openflag) {
	var tmpName = "";
	if(nowPage == "local") {
		tmpName = filepath.replace(nowPath, "");
		filepath = fileSystemRootPath + filepath;
		if(filepath.match("file://")) {
			filepath = filepath.substring(("file://").length);
		}
	} else if(nowPage == "server") {
		path = tmpLocalRootPath +"/"+ECMFolder;
		tmpName = filepath.replace(path, "");
	}

	srcPath = tmpName.substring(tmpName.lastIndexOf('/'));
	FileExtensionArr = new Array();
	FileExtensionArr = srcPath.split(".");
	extension = FileExtensionArr[1];
	viewer = GetlocalStorage("Officesuite");
	file_open = GetlocalStorage("file_open");

	if(extension == "doc" || extension == "docx" || extension == "ppt" || extension == "pptx"
		 || extension == "xls" || extension == "xlsx" || extension == "txt" || extension == "pdf") {
		if(file_open == "viewer" && viewer == "nonexistent") {
			alertMessage("not installed officesuite");
			return;
    	}
    }

	index = tmpName.lastIndexOf('.');
	extension = tmpName.substring(index + 1).toLowerCase();
	siteid = GetlocalStorage("SiteID");
	user = GetsessionStorage("UserID");
	if(extension == "secure") {
		window.resolveLocalFileSystemURL("file:///sdcard", function(resolveFileSystem){
			resolveFileSystem.getDirectory("dcrypt_tmp", {create: true, exclusive: false}, function(destpath){
				destpath = destpath.fullPath + tmpName.substring(0, index);
				CryptUtil.decrypt(SuccessDecrypt, function(e){alert('Local file decrypt error!');}, siteid, user, filepath, destpath);
			}, failMsg);
		}, failMsg);
	} else {
		CallApp(filepath, openflag, extension, siteid, user, "");
	}
}

/*
 * Local 파일이 .encrypt되어있을 경우 복호화 후 열기 시도
 */
function SuccessDecrypt(destpath) {
	var tmpName = destpath.substring(destpath.lastIndexOf('/'));
	var index = tmpName.lastIndexOf('.');
	var extension = tmpName.substring(index + 1).toLowerCase();
	openflag = "Local";
	siteid = GetlocalStorage("SiteID");
	user = GetsessionStorage("UserID");
	CallApp(destpath, openflag, extension, siteid, user);
}

// Local 파일을 열 application 선택
function CallApp(filepath, openflag, extension, siteid, user) {
	filepath = encodeURI(filepath);
	if(openflag == "Server" && GetsessionStorage("runWay") == "choice") {
		flag = "*";
		AppManager.callappAt(finishCallApp, function(){}, filepath, extension, flag, openflag, siteid, user, "");
		return;
	}
	
	if(extension == "mp4" || extension == "avi" || extension == "3gp")
	{		
		flag = "video";
		AppManager.callapp(function(){}, function(){}, filepath, extension, flag, openflag, siteid, user, "");
	}
	else if(extension == "mp3" || extension == "wma")
	{
		flag = "music";
		AppManager.callapp(function(){}, function(){}, filepath, extension, flag, openflag, siteid, user, "");
	}
	else if(extension == "jpg" || extension == "gif" || extension == "png")
	{
		flag = "imgage";
		AppManager.callapp(function(){}, function(){}, filepath, extension, flag, openflag, siteid, user, "");
	}
	else if(extension == "doc" || extension == "docx" || extension == "ppt" || extension == "pptx" || extension == "xls"
			|| extension == "xlsx" || extension == "txt" || extension == "pdf" || extension == "hwp" || extension == "html")
	{
		//viewer = GetlocalStorage("Officesuite");
		file_open = GetlocalStorage("file_open");
		/*if( file_open == "viewer" && viewer == "nonexistent" ) {
			alert("not exist Officesuite");
			return;
		}*/
		flag = "document";
		AppManager.callapp(finishCallApp, function(){}, filepath, extension, flag, openflag, siteid, user, file_open);
	}
	else
	{
		navigator.notification.alert(lang_alert_not_support_format, function(){}, 'Explorer', 'OK');
	}
}

// 파일 열기 잡업 완료 후, 진행창 초기화
function finishCallApp() {
	clearInterval(downfile);
	clearInterval(downfileoverwrite);
	clearInterval(downfileoffset);
}

// 사진 촬영 후 업로드
function CallCamera() {
	closeCameraDialog();
	Entertainment.Photo(SuccessCamera, function(){});
	cameraFlag = "camera"; // gallery or camera
}

// 동영상 촬영 후 업로드
function CallVideo() {
	closeCameraDialog();
	Entertainment.Video(SuccessCamera, function(){});
	cameraFlag = "camera"; // gallery or camera
}

// 갤러리로부터 업로드
function GetGallery(){
	cameraFlag = "gallery"; // gallery or camera
	cameraExport.getPicture(SuccessCamera, onCameraFail, { quality: 75,
                                destinationType: Camera.DestinationType.FILE_URI,
                                sourceType : Camera.PictureSourceType.SAVEDPHOTOALBUM,
                                mediaType : Camera.MediaType.ALLMEDIA}); 
}

function onSuccessCamera(imageURI) {
	navigator.notification.alert(imageURI, function(){}, 'Camera', 'OK');
}

function onCameraFail(r) {
	navigator.notification.alert('Fail : ' + r, function(){}, 'Camera', 'OK');
}

// 사진 업로드
function GetGalleryPhoto() {
	closeCameraDialog();
	Entertainment.GalleryPhoto(SuccessCamera, function(){});
	cameraFlag = "gallery";
}

// 동영상 업로드
function GetGalleryVideo() {
	closeCameraDialog();
	Entertainment.GalleryVideo(SuccessCamera, function(){});
	cameraFlag = "gallery";
}

function SuccessCamera(retV) {
	if(nowPage == "server") {
		attribute = "0";
		siteid = GetlocalStorage("SiteID");
		Agent = GetlocalStorage("Platform");
		User = GetsessionStorage("UserID");
		overwrite = "";
		offset = "";
		option = "";
		if(paraDiskType == "personal") option = "0x01";
		upfile = setInterval(uploadprogress, 10);
		showUpDownProgressbar();

		useSSL = GetlocalStorage("SSL");
		FileServerPort = "";
		if(useSSL == "yes") FileServerPort = GetlocalStorage("FileSSlPort");
		else FileServerPort = GetlocalStorage("FileHttpPort");
		SetsessionStorage("tmpPicturePath", retV);

		UpDownManager.upload(SuccessUpload, function(){}, tmpDomainID, paraDiskType, User, tmpPartition, tmpWebServer, Agent, option, tmpOwner, tmpShareUser,
                             tmpShareOwner, tmpStartPath, tmpOrgCode, tmpUserPath, tmpFileServer, useSSL, FileServerPort, siteid, retV, overwrite, offset);
	}
}

// capture callback
function captureSuccess(mediaFiles) {
    var i, path, len;
    for (i = 0, len = mediaFiles.length; i < len; i += 1) {
        path = mediaFiles[i].fullPath;
        // do something interesting with the file
    }
    SuccessCamera(path);
};

// capture error callback
function captureError(error) {
    navigator.notification.alert('Error code: ' + error.code, null, 'Capture Error');
};

/* 덮어쓰기
 * checkConnection() -> confirmMobile() -> download() -> SuccessDownLoad() -> ConfirmDownOverwrite()
 */
function ConfirmDownOverwrite(value) {
	downfile = setInterval(downloadprogress, 10);
	showUpDownProgressbar();

	if(value == "2")	download("yes", "no");
	else				download("no", "no");
}

/* 
 * checkConnection() -> confirmMobile() -> download() -> SuccessDownLoad() -> confirmDownOffset()
 */
function confirmDownOffset(value) {
	downfile = setInterval(downloadprogress, 10);
	showUpDownProgressbar();
	
	if(value == "2")	download("no", "yes");
    else				download("no", "no");
}

// Cordova 수행작업 실패시 에러메시지
function failMsg(error) {
	if(error.code == 1) {
		navigator.notification.alert(lang_alert_not_found_err, function(){}, 'Explorer', 'OK');
	} else if(error.code == 2) {
		navigator.notification.alert(lang_alert_security_err, function(){}, 'Explorer', 'OK');
	} else if(error.code == 3) {
		navigator.notification.alert(lang_alert_abort_err, function(){}, 'Explorer', 'OK');
	} else if(error.code == 4) {
		navigator.notification.alert(lang_alert_not_readable_err, function(){}, 'Explorer', 'OK');
	} else if(error.code == 5) {
		navigator.notification.alert(lang_alert_encoding_err, function(){}, 'Explorer', 'OK');
	} else if(error.code == 6) {
		navigator.notification.alert(lang_alert_no_modification_allowed_err, function(){}, 'Explorer', 'OK');
	} else if(error.code == 7) {
		navigator.notification.alert(lang_alert_invalid_state_err, function(){}, 'Explorer', 'OK');
	} else if(error.code == 8) {
		navigator.notification.alert(lang_alert_syntax_err, function(){}, 'Explorer', 'OK');
	} else if(error.code == 9) {
		navigator.notification.alert(lang_alert_invalid_modification_err, function(){}, 'Explorer', 'OK');
	} else if(error.code == 10) {
		navigator.notification.alert(lang_alert_quota_exceeded_err, function(){}, 'Explorer', 'OK');
	} else if(error.code == 11) {
		navigator.notification.alert(lang_alert_type_mismatch_err, function(){}, 'Explorer', 'OK');
	} else if(error.code == 12) {
		navigator.notification.alert(lang_alert_path_exists_err, function(){}, 'Explorer', 'OK');
	}
}
