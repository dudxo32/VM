// 정렬할 파일목록 가져오기
function sort_getList() {
	var retList;
	
	if(nowPage == "server") {
		retList= $('#explorerList li');
		$('#explorerList li').remove();
	} else if(nowPage == "local") {
		retList= $('#localList li');
		$('#localList li').remove();
	}
	return retList;
}

// 리스트 파일 이름 가져오기
function getListFileName(fileInfo) {
	listForName1= fileInfo.innerHTML.split("<div id=\"file_info_name\">");
	listForName2= listForName1[1].split("</div>");
	return listForName2[0];
}

// 리스트 파일 날짜 가져오기
function getListFileDate(fileInfo) {
	listForName1= fileInfo.innerHTML.split("<div id=\"file_info_date\">");
	listForName2= listForName1[1].split("</div>");
	return listForName2[0];
}

// 오름차순 정렬
function sort_LtH() {
    closeSortDialog();
	var folder_num= 0;
	var file_num= 0;
	var check_list= sort_getList();

    for(i=0; i < check_list.length; i++) {
		if(check_list[i].className == "folder")	++folder_num;
		else									++file_num;
	}
        
	qSort_LtH("folder", check_list, 0, folder_num-1);
	qSort_LtH("file", check_list, folder_num, check_list.length-1);

	for(i=0; i < check_list.length; i++) {
		if(check_list[i].className == "folder") {
			if(nowPage == "server")		$('#explorerList').append("<li class='folder'>"+ check_list[i].innerHTML+ "</li>");
			else if(nowPage == "local")	$('#localList').append("<li class='folder'>"+ check_list[i].innerHTML+ "</li>");
		}
	}
	for(i=0; i < check_list.length; i++) {
		if(check_list[i].className == "file") {
			if(nowPage == "server")		$('#explorerList').append("<li class='file'>"+ check_list[i].innerHTML+ "</li>");
			else if(nowPage == "local")	$('#localList').append("<li class='file'>"+ check_list[i].innerHTML+ "</li>");
		}
	}
}
/* 오름차순으로 정리
 * sort_LtH() -> qSort_LtH()
 */
function qSort_LtH(flag, list, left, right) {
	var pivot, l_hold, r_hold;
	l_hold= left;
	r_hold= right;
	pivot= list[left];

	while(left < right) {
		while((getListFileName(list[right]) >= getListFileName(pivot)) && (left < right))	right--;
		if(left != right)	list[left] = list[right];
		
		while((getListFileName(list[left]) <= getListFileName(pivot)) && (left < right))	left++;
		if(left != right) {
			list[right] = list[left];
			right--;
		}
	}

	list[left]= pivot;
	pivot= left;
	left= l_hold;
	right= r_hold;
	
	if(left < pivot) {
		if(flag == "folder")	qSort_LtH("folder", list, left, pivot-1);
		else					qSort_LtH("file", list, left, pivot-1);
	}
	if(right > pivot) {
		if(flag == "folder")	qSort_LtH("folder", list, pivot+1, right);
		else					qSort_LtH("file", list, pivot+1, right);
	}
}

// 내림차순 정렬
function sort_HtL() {
    closeSortDialog();
	var folder_num= 0;
	var file_num= 0;
	var check_list= sort_getList();
	
	for(i=0; i < check_list.length; i++) {
		if(check_list[i].className == "folder")	++folder_num;
		else									++file_num;
	}

	qSort_HtL("folder", check_list, 0, folder_num-1);
	qSort_HtL("file", check_list, folder_num, check_list.length-1);
	
	for(i=0; i < check_list.length; i++) {
		if(check_list[i].className == "folder") {
			if(nowPage == "server")		$('#explorerList').append("<li class='folder'>"+ check_list[i].innerHTML+ "</li>");
			else if(nowPage == "local")	$('#localList').append("<li class='folder'>"+ check_list[i].innerHTML+ "</li>");
		}
	}
	for(i=0; i < check_list.length; i++) {
		if(check_list[i].className == "file") {
			if(nowPage == "server")		$('#explorerList').append("<li class='file'>"+ check_list[i].innerHTML+ "</li>");
			else if(nowPage == "local")	$('#localList').append("<li class='file'>"+ check_list[i].innerHTML+ "</li>");
		}
	}
}
/* 내림차순으로 정리
 * sort_HtL() -> qSort_HtL()
 */
function qSort_HtL(flag, list, left, right) {
	var pivot, l_hold, r_hold;
	l_hold= left;
	r_hold= right;
	pivot= list[left];

	while(left < right) {
		while((getListFileName(list[right]) <= getListFileName(pivot)) && (left < right))	right--;
		if(left != right)	list[left] = list[right];
		
		while((getListFileName(list[left]) >= getListFileName(pivot)) && (left < right))	left++;
		if(left != right) {
			list[right] = list[left];
			right--;
		}
	}

	list[left]= pivot;
	pivot= left;
	left= l_hold;
	right= r_hold;
	
	if(left < pivot) {
		if(flag == "folder")	qSort_HtL("folder", list, left, pivot-1);
		else					qSort_HtL("file", list, left, pivot-1);
	}
	if(right > pivot) {
		if(flag == "folder")	qSort_HtL("folder", list, pivot+1, right);
		else					qSort_HtL("file", list, pivot+1, right);
	}
}

// 최신 항목 정렬
function sort_new() {
    closeSortDialog();
	var folder_num= 0;
	var file_num= 0;
	var check_list= sort_getList();
	
	for(i=0; i < check_list.length; i++) {
		if(check_list[i].className == "folder")	++folder_num;
		else									++file_num;
	}

	qSort_new("folder", check_list, 0, folder_num-1);
	qSort_new("file", check_list, folder_num, check_list.length-1);
	
	for(i=0; i < check_list.length; i++) {
		if(check_list[i].className == "folder") {
			if(nowPage == "server")		$('#explorerList').append("<li class='folder'>"+ check_list[i].innerHTML+ "</li>");
			else if(nowPage == "local")	$('#localList').append("<li class='folder'>"+ check_list[i].innerHTML+ "</li>");
		}
	}
	for(i=0; i < check_list.length; i++) {
		if(check_list[i].className == "file") {
			if(nowPage == "server")		$('#explorerList').append("<li class='file'>"+ check_list[i].innerHTML+ "</li>");
			else if(nowPage == "local")	$('#localList').append("<li class='file'>"+ check_list[i].innerHTML+ "</li>");
		}
	}
}
/* 최신 항목순으로 정리
 * sort_new() -> qSort_new()
 */
function qSort_new(flag, list, left, right) {
	var pivot, l_hold, r_hold;
	l_hold= left;
	r_hold= right;
	pivot= list[left];

	while(left < right) {
		while((getListFileDate(list[right]) <= getListFileDate(pivot)) && (left < right))	right--;
		if(left != right)	list[left] = list[right];
		
		while((getListFileDate(list[left]) >= getListFileDate(pivot)) && (left < right))	left++;
		if(left != right) {
			list[right] = list[left];
			right--;
		}
	}

	list[left]= pivot;
	pivot= left;
	left= l_hold;
	right= r_hold;
	
	if(left < pivot) {
		if(flag == "folder")	qSort_new("folder", list, left, pivot-1);
		else					qSort_new("file", list, left, pivot-1);
	}
	if(right > pivot) {
		if(flag == "folder")	qSort_new("folder", list, pivot+1, right);
		else					qSort_new("file", list, pivot+1, right);
	}
}

// 오래된 항목 정렬
function sort_old() {
    closeSortDialog();
	var folder_num= 0;
	var file_num= 0;
	var check_list= sort_getList();
	
	for(i=0; i < check_list.length; i++) {
		if(check_list[i].className == "folder")	++folder_num;
		else									++file_num;
	}

	qSort_old("folder", check_list, 0, folder_num-1);
	qSort_old("file", check_list, folder_num, check_list.length-1);
	
	for(i=0; i < check_list.length; i++) {
		if(check_list[i].className == "folder") {
			if(nowPage == "server")		$('#explorerList').append("<li class='folder'>"+ check_list[i].innerHTML+ "</li>");
			else if(nowPage == "local")	$('#localList').append("<li class='folder'>"+ check_list[i].innerHTML+ "</li>");
		}
	}
	for(i=0; i < check_list.length; i++) {
		if(check_list[i].className == "file") {
			if(nowPage == "server")		$('#explorerList').append("<li class='file'>"+ check_list[i].innerHTML+ "</li>");
			else if(nowPage == "local")	$('#localList').append("<li class='file'>"+ check_list[i].innerHTML+ "</li>");
		}
	}
}
/* 오래된 항목순으로 정리
 * sort_old() -> qSort_old()
 */
function qSort_old(flag, list, left, right) {
	var pivot, l_hold, r_hold;
	l_hold= left;
	r_hold= right;
	pivot= list[left];

	while(left < right) {
		while((getListFileDate(list[right]) >= getListFileDate(pivot)) && (left < right))	right--;
		if(left != right)	list[left] = list[right];
		
		while((getListFileDate(list[left]) <= getListFileDate(pivot)) && (left < right))	left++;
		if(left != right) {
			list[right] = list[left];
			right--;
		}
	}

	list[left]= pivot;
	pivot= left;
	left= l_hold;
	right= r_hold;
	
	if(left < pivot) {
		if(flag == "folder")	qSort_old("folder", list, left, pivot-1);
		else					qSort_old("file", list, left, pivot-1);
	}
	if(right > pivot) {
		if(flag == "folder")	qSort_old("folder", list, pivot+1, right);
		else					qSort_old("file", list, pivot+1, right);
	}
}
