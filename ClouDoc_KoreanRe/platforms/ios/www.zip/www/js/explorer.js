/* FUNCTION LIST
 * 
 * showBlank()
 * hideBlank()
 * openDocumentSelect()
 * closeDocumentSelect()
 * openMenu()
 * closeMenu()
 * openSortDialog()
 * closeSortDialog()
 * openFileFuncDialog(fileName)
 * closeFileFuncDialog()
 * openCameraDialog()
 * closeCameraDialog()
 * openNewFolderDialog()
 * closeNewFolderDialog()
 * openRenameDialog()
 * closeRenameDialog()
 * closeAll()
 * showToast()
 * 
 * selectServer()
 * selectLocal()
 * menuSelectServer()
 * menuSelectLocal()
 * changeToServer()
 * changeToServerForm()
 * changeToLocal()
 * serverDocumentBoxFunction()
 * localDocumentBoxFunction()
 * singleMode()
 * multipleMode()
 * workMode()
 * singleModeOn()
 * singleModeOff()
 * multipleAll()
 * multipleAllCancel()
 * fileSelect(object)
 * f_copy()
 * snip()
 * paste()
 * deleteFile()
 * ConfirmdeleteFile(value)
 * newFolderCreate()
 * rename()
 * showUpDownProgressbar()
 * hiddenUpDownProgressbar()
 * updownCancel()
 */
var explorer_lang_title_server = "";
var explorer_lang_title_local = "";
var nowFunc = "none";

// 블랭크 화면 보이기
function showBlank() {
	$('#blank').css('display', 'block');
}

// 블랭크 화면 숨기기
function hideBlank() {
	$('#blank').css('display', 'none');
}

// 문서함 변경 선택창 열기
function openDocumentSelect() {
	closeAll();
	$('#document_select').slideToggle("fast");

	$('.explorer_title').prop('onclick', null);
	$('.explorer_title').off('click', openDocumentSelect);
	$('.explorer_title').on('click', closeDocumentSelect);

	$('#blank').on('click', closeDocumentSelect);
	$('#blank').css('margin-top', $('#explorerTitle').height());
	showBlank();
}

// 문서함 변경 선택창 닫기
function closeDocumentSelect() {
	$('#document_select').slideToggle("fast");

	$('.explorer_title').off('click', closeDocumentSelect);
	$('.explorer_title').on('click', openDocumentSelect);

	$('#blank').off('click', closeDocumentSelect);
	$('#blank').css('margin-top', '0');
	hideBlank();
}

//좌측메뉴 열기
function openMenu() {
	closeAll();
	$('#menu').animate({width: "toggle"}, 100);
	$('#blank').on('click', closeMenu);
	showBlank();
}

// 좌측메뉴 닫기
function closeMenu() {
	$('#menu').animate({width: "toggle"}, 100);
	$('#blank').off('click', closeMenu);
	hideBlank();
}

//파일 목록 정렬창 열기
function openSortDialog() {
	closeAll();
	$('#sortModal').css('display', 'block');
	
	$('#blank').on('click', closeSortDialog);
	showBlank();
}

// 파일 목록 정렬창 닫기
function closeSortDialog() {
	$('#sortModal').css('display', 'none');
	
	$('#blank').off('click', closeSortDialog);
	hideBlank();
}

// 단일파일 작업창 표시
function openFileFuncDialog(fileName) {
	closeAll();
	if(nowPage == "server")
		check_list = $("#explorerList input:checkbox");
	else if(nowPage == "local")
		check_list = $("#localList input:checkbox");
	
	for(i=0; i< check_list.length; i++) {
		if(check_list[i].id == fileName)
			check_list[i].checked= true;
	}

	$('#fileFunc_lang_title').text(fileName);
	$('#fileFuncModal').css('display', 'block');

	// 파일명 길이 조절
	var gap = $('#maxFileNameWidth').width() * 0.9 - $('#fileFunc_lang_title').width();
	if(gap < 0) {
		var extension = fileName.substring(fileName.lastIndexOf('.') + 1);
		var realFileName = fileName.substring(0, fileName.lastIndexOf('.'));
		var tempFileName = "";
		while(gap < 0) {
			realFileName = realFileName.substring(0, realFileName.length-1);
			tempFileName = realFileName + "." + extension;
			$('#fileFunc_lang_title').text(tempFileName);
			gap = $('#maxFileNameWidth').width() * 0.7 - $('#fileFunc_lang_title').width();
		}
		fileName = realFileName + "..." + fileName.substring(fileName.lastIndexOf('.')-3, fileName.lastIndexOf('.')) + "." + extension;
		$('#fileFunc_lang_title').text(fileName);
	}
	
	$('#blank').on('click', closeFileFuncDialog);
	showBlank();
}

// 단일파일 작업창 숨기기
function closeFileFuncDialog() {
	$('#fileFuncModal').css('display', 'none');
	
	$('#blank').off('click', closeFileFuncDialog);
	hideBlank();
}

// 카메라 작업 창 열기
function openCameraDialog() {
	closeAll();
	$('#cameraUploadDialog').slideDown('fast');
	showBlank();
}

// 카메라 작업 창 닫기
function closeCameraDialog() {
	$('#cameraUploadDialog').slideUp('fast');
	hideBlank();
}

// 새폴더 생성 화면
function openNewFolderDialog() {
	closeAll();
	$('#newFolderForm').css('display', 'block');

	$('#blank').on('click', closeNewFolderDialog);
	showBlank();
}

// 새폴더 취소
function closeNewFolderDialog() {
	$('#newFolderName').val('');
	$('#newFolderForm').css('display', 'none');

	$('#blank').off('click', openNewFolderDialog);
	hideBlank();
}

//파일명 변경 화면
function openRenameDialog() {
	closeAll();

	if(nowPage == "server") {
		var checked_list = $("#explorerList input:checkbox:checked");
		var tmpFilename = checked_list[0].value;
		var extension = "";
		if(tmpFilename.lastIndexOf('.') != -1) {
			index = tmpFilename.lastIndexOf('.');
			extension = tmpFilename.substring(index + 1).toLowerCase();
			reNameTmpFile = tmpFilename.split("." + extension);
			$('#renameName').val(reNameTmpFile[0]);
			$('#renameExtension').val(extension);
		} else {
			$('#renameName').val(checked_list[0].value);
			extension = "";
	    }
	} else if(nowPage == "local") {
		var checked_list = $("#localList input:checkbox:checked");
		var tmpFilePath= checked_list[0].value;
		var tmpFilename = tmpFilePath.substring(tmpFilePath.lastIndexOf("/")+1);
		var extension = "";
		
		if(tmpFilename.lastIndexOf('.') != -1) {
			index= tmpFilename.lastIndexOf('.');
			extension= tmpFilename.substring(index+1).toLowerCase();
			// Server로부터 다운받아 암호화된 파일
			if(extension == "secure") {
				var split= tmpFilename.split('.');
				extension= split[split.length-2]+ "."+ split[split.length-1];
				extension= extension.toLowerCase();
				reNameTmpFile= tmpFilename.split("." + extension);
			}
			// 사용자에 의하여 생성된 파일
			else {
				reNameTmpFile = tmpFilename.split("." + extension);
			}
			$('#renameName').val(reNameTmpFile[0]);
			$('#renameExtension').val(extension);
		} else {
			var tempName = checked_list[0].value.substring(0, checked_list[0].value.lastIndexOf('/'));
			$('#renameName').val(tempName.substring(tempName.lastIndexOf('/')+1));
			extension = "";
	    }
	}
	
	$('#renameForm').css('display', 'block');
	$('#blank').on('click', closeRenameDialog);
	showBlank();
}

// 파일명 변경 취소
function closeRenameDialog() {
	$('#renameName').val('');
	$('#renameExtension').val('');
	
	$('#renameForm').css('display', 'none');

	$('#blank').off('click', closeRenameDialog);
	hideBlank();
	singleMode();
}

// 모든 창 닫기
function closeAll() {
	if($('#document_select').css('display') != "none")	closeDocumentSelect();
	if($('#menu').css('display') != "none")	closeMenu();
	if($('#sortModal').css('display') != "none")	closeSortDialog();
	if($('#fileFuncModal').css('display') != "none")	closeFileFuncDialog();
	if($('#cameraUploadDialog').css('display') != "none")	closeCameraDialog();
	if($('#newFolderForm').css('display') != "none")	closeNewFolderDialog();
	if($('#renameForm').css('display') != "none")	closeRenameDialog();
	if($('#explorerTitle_select').css('display') != "none")	singleMode();
}

// 토스트창 보여주기
function showToast(message) {
	$('#toastContent').text(message);
	$('#toast').fadeIn(1500);
	setTimeout(hideToast, 1000);
}

// 토스트창 감추기
function hideToast() {
	$('#toast').fadeOut(1500);
}

// explorerForm에서 서버문서함으로 변경 선택
function selectServer() {
	closeDocumentSelect();
	changeToServer();
}

//explorerForm에서 로컬문서함으로 변경 선택
function selectLocal() {
	closeDocumentSelect();
	changeToLocal();
}

// 좌측메뉴에서 서버문서함으로 변경 선택
function menuSelectServer() {
	closeMenu();
	changeToServer();
}

//좌측메뉴에서 로컬문서함으로 변경 선택
function menuSelectLocal() {
	closeMenu();
	changeToLocal();
}

/* 서버문서함으로 변경
 * selectServer() -> changeToServer()
 */
function changeToServer() {
	changeToServerForm();
	getDriveList();
}

function changeToServerForm() {
	$('#explorerList').css('display', 'block');
	$('#localList').css('display', 'none');
	
	$('#explorerTool_normal').css('display', 'table');
	$('#explorerTool_work').css('display', 'none');
}

/* 로컬문서함으로 변경
 * selectLocal() -> changeToLocal()
 */
function changeToLocal() {
	$('#explorerList').css('display', 'none');
	$('#localList').css('display', 'block');
	
	$('#explorerTool_normalOn').css('display', 'none');
	$('#explorerTool_normalOff').css('display', 'none');
	$('#explorerTool_work').css('display', 'flex');
	
	getLocalList();
}

// 좌측메뉴_서버문서함 여닫기
function serverDocumentBoxFunction() {
	serverDocumentBox= document.getElementById('serverDocumentBox');
	serverDocumentList= document.getElementById('serverDocumentList');
	var height= $(serverDocumentBox).height(); 
	
	if(serverDocumentList.style.display !== 'none') {
		serverDocumentList.style.display= 'none';
		serverDocumentBox.style.borderBottom= '2px solid #C6C6C6';
		serverDocumentBox.style.height= (height+2)+ 'px';
		$('#serverDocumentBox_btn img').attr('src', 'img/downBtnBlack.png');
	}
	else {
		serverDocumentList.style.display= 'block';
		serverDocumentBox.style.borderBottom= '1px solid #C6C6C6';
		serverDocumentBox.style.height= (height+1)+ 'px';
		$('#serverDocumentBox_btn img').attr('src', 'img/upBtnBlack.png');
	}
}

//좌측메뉴_로컬문서함 여닫기
function localDocumentBoxFunction() {
	var localDocumentList = document.getElementById('localDocumentList');
	
	if(localDocumentList.style.display !== 'none') {
		localDocumentList.style.display= 'none';
		$('#localDocumentBox_btn img').attr('src', 'img/downBtnBlack.png');
	}
	else {
		localDocumentList.style.display= 'block';
		$('#localDocumentBox_btn img').attr('src', 'img/upBtnBlack.png');
	}
}

// 단일파일 모드
function singleMode() {
	// 탐색기 상단
	$('#explorerTitle_normal').css('display', 'table-row');
	$('#explorerTitle_select').css('display', 'none');
	$('#explorerTitle_work').css('display', 'none');
	// 리스트 버튼
	$('.file_func').css('display', 'block');
	$('.file_select').css('display', 'none');
	$('.file_noneFunc').css('display', 'none');
	// 하단 툴바
	if(nowPage == "local") {
		$('#explorerTool_normalOn').css('display', 'none');
		$('#explorerTool_normalOff').css('display', 'none');
		$('#explorerTool_selected').css('display', 'none');
		$('#explorerTool_work').css('display', 'flex');
	} else {
		$('#explorerTool_normalOn').css('display', 'flex');
		$('#explorerTool_normalOff').css('display', 'none');
		$('#explorerTool_selected').css('display', 'none');
		$('#explorerTool_work').css('display', 'none');
	}
	
	// 파일 전체 선택이였을 경우 해제
	$('#multiple_lang_allSelcet').css('color', '#FFFFFF');
	
	multipleAllCancel();
}

// 다중파일 선택 모드
function multipleMode() {
	nowFunc = "multiple";
	multipleAllCancel();
	closeAll();

	// 탐색기 상단
	$('#explorerTitle_normal').css('display', 'none');
	$('#explorerTitle_select').css('display', 'table-row');
	$('#explorerTitle_work').css('display', 'none');
	// 리스트 버튼
	$('.file_func').css('display', 'none');
	$('.file_select').css('display', 'block');
	$('.file_noneFunc').css('display', 'none');
	// 하단 툴바
	$('#explorerTool_normalOn').css('display', 'none');
	$('#explorerTool_normalOff').css('display', 'none');
	$('#explorerTool_selected').css('display', 'flex');
	$('#explorerTool_work').css('display', 'none');
	
}

// 파일작업 모드
function workMode() {
	// 탐색기 상단
	$('#explorerTitle_normal').css('display', 'none');
	$('#explorerTitle_select').css('display', 'none');
	$('#explorerTitle_work').css('display', 'table-row');
	// 리스트 버튼
	$('.file_func').css('display', 'none');
	$('.file_select').css('display', 'none');
	$('.file_noneFunc').css('display', 'block');
	// 하단 툴바
	$('#explorerTool_normalOn').css('display', 'none');
	$('#explorerTool_normalOff').css('display', 'none');
	$('#explorerTool_selected').css('display', 'none');
	$('#explorerTool_work').css('display', 'flex');
}

// 단일파일 하단 툴바 On 
function singleModeOn() {
	$('#explorerTool_normalOn').css('display', 'flex')
	$('#explorerTool_normalOff').css('display', 'none')
}

// 단일파일 하단 툴바 Off
function singleModeOff() {
	$('#explorerTool_normalOn').css('display', 'none')
	$('#explorerTool_normalOff').css('display', 'flex')
}

// 파일 전체 선택
function multipleAll() {
	if(nowPage == "server") {
		check_list = $('#explorerList input:checkbox');
		checked_list= $('#explorerList input:checkbox:checked');
	} else if(nowPage == "local") {
		check_list = $('#localList input:checkbox');
		checked_list= $('#localList input:checkbox:checked');
	}
	
	if(check_list.length == checked_list.length) {
		for(i=0; i< check_list.length; i++) {
			check_list[i].checked= false;
			$('#multiple_lang_allSelcet').css('color', '#FFFFFF');
		}
	} else {
		for(i=0; i< check_list.length; i++) {
			check_list[i].checked= true;
			$('#multiple_lang_allSelcet').css('color', '#0A71A5');
		}
	}
}

// 파일 전체 선택 취소
function multipleAllCancel() {
	if(nowPage == "server")
		check_list = $("#explorerList input:checkbox");
	else if(nowPage == "local")
		check_list = $("#localList input:checkbox");
	
	for(i=0; i< check_list.length; i++) {
		check_list[i].checked= false;
	}
	
	$('#multiple_lang_allSelcet').css('color', '#FFFFFF');
	
}

// 전체 선택됬을 시 '전체'버튼 색변경
function fileSelect(object) {
	if(nowPage == "server") {
		check_list = $('#explorerList input:checkbox');
		checked_list= $('#explorerList input:checkbox:checked');
	} else if(nowPage == 'local') {
		check_list = $('#localList input:checkbox');
		checked_list= $('#localList input:checkbox:checked');
	}

	for(i=0; i < check_list.length; i++) {
		if(check_list[i].id == object)
			target= check_list[i].checked;
	}

	if(target) {
		$('#multiple_lang_allSelcet').css('color', '#FFFFFF');
	} else {
		if(check_list.length == checked_list.length+1)
			$('#multiple_lang_allSelcet').css('color', '#0A71A5');
		else
			$('#multiple_lang_allSelcet').css('color', '#FFFFFF');
	}
}

// 파일 복사
function f_copy() {
	closeFileFuncDialog();
	tmpAction = "copy";

	if(nowPage == "server") {
		tmpFrom = "server";
		checked_list = $("#explorerList input:checkbox:checked");

		tmpCheckedList = new Array();
		tmpCheckedListAttribute = new Array();
		for(i=0; i < checked_list.length; i++) {
			tmpCheckedList.push(checked_list[i].value);
			tmpCheckedListAttribute.push(checked_list[i].alt);	// size & type(folder/file)
		}

		saveFileServer = tmpFileServer;
		savePartition = tmpPartition;
		saveDiskType = tmpDiskType;
		saveOwner = tmpOwner;
		saveStartPath = tmpStartPath;
		saveUserPath = tmpUserPath;
		saveShareUser = tmpShareUser;
		saveShareOwner = tmpShareOwner;
		saveSharePath = tmpSharePath;
		
		getDriveList();
	} else if ( nowPage == "local" ) {
		tmpFrom = "local";
		checked_list = $("#localList input:checkbox:checked");

		tmpCheckedList = new Array();
		for(i=0; i< checked_list.length; i++) {
			var tempName = fileSystemRootPath.substring(0, fileSystemRootPath.length-1) + checked_list[i].value;
			if(tempName.match("file://")) tempName = tempName.substring(("file://").length);
			tmpCheckedList.push(tempName);
		}
		
		getLocalList();
	}
	
	workMode();
}

// 파일 잘라내기
function snip() {
	closeFileFuncDialog();
	
	tmpAction = "snip";
	if(nowPage == "server") {
		tmpFrom = "server";
		checked_list = $("#explorerList input:checkbox:checked");

		tmpCheckedList = new Array();
		tmpCheckedListAttribute = new Array();
		for(i=0; i < checked_list.length; i++) {
			tmpCheckedList.push(checked_list[i].value);
			tmpCheckedListAttribute.push(checked_list[i].alt);
		}

		saveFileServer = tmpFileServer;
		savePartition = tmpPartition;
		saveDiskType = tmpDiskType;
		saveOwner = tmpOwner;
		saveStartPath = tmpStartPath;
		saveUserPath = tmpUserPath;
		saveShareUser = tmpShareUser;
		saveShareOwner = tmpShareOwner;
		saveSharePath = tmpSharePath;
		
		getDriveList();
	} else if(nowPage == "local") {
		tmpFrom = "local";
		checked_list = $("#localList input:checkbox:checked");

		tmpCheckedList = new Array();
		for(i=0; i < checked_list.length; i++) {
			tmpCheckedList.push(checked_list[i].value);
		}
		
		getLocalList();
	}

	workMode();
}

// 복사/이동할 파일 붙이기
function paste() {
	if(tmpFrom == "server" && nowPage == "server") {
		if(tmpAction == "snip")	SeverMoveFile();
		else 					ServerCopyFile();
	} else if(tmpFrom == "server" && nowPage == "local") {
		if(tmpAction == "copy") {
			flag = "download";
			checkConnection("download");
		} else
			alert("Server에서 Local로 파일 이동은 불가능합니다.");
	} else if(tmpFrom == "local" && nowPage == "local") {
		if(tmpAction == "snip")	LocalMove();
		else					LocalCopy();
	} else if(tmpFrom == "local" && nowPage == "server") {
		if(tmpAction == "copy")
			checkConnection("upload");
		else
			alert("Server에서 Local로 파일 이동은 불가능합니다.");
	}
	
	showToast("복사/이동이 완료되었습니다.");
	singleMode();
}

// 파일 삭제
function deleteFile() {
	closeFileFuncDialog();
	
	if(nowPage == "server")		checked_list = $("#explorerList input:checkbox:checked");
	else if(nowPage == "local")	checked_list = $("#localList input:checkbox:checked");
	
	navigator.notification.confirm(/* lang_alert_delete, */'삭제하시겠습니까?', ConfirmdeleteFile, 'Explorer', ['No', 'Yes']);
}

// 파일 삭제 승인
function ConfirmdeleteFile(value) {
	if(value == "2") {
		if(nowPage == "server") {
			ServerDeleteFile();
		} else {
            LocalDeleteFile();
        }
    }
}

//새폴더 생성
function newFolderCreate() {
	var newfoldername = $('#newFolderName').val();
	
	// 폴더명이 비었을 경우 
	if(newfoldername == "") {
		navigator.notification.alert(lang_alert_valid_folder_name, "", 'Explorer', 'OK');
		return;
	}

	// 폴더명을 입력하였을 경우
	if(nowPage == "server")
		newServerFolder(newfoldername);
	else if (nowPage == "local")
		newLocalFolder(newfoldername);

	closeNewFolderDialog();
}

// 파일명 변경
function rename() {
	filename = $('#renameName').val();
	extension = $('#renameExtension').val();

	if(extension != "") {
        filename = filename + "." + extension;
        $('#renameExtension').val('');
        extension = "";
	}
	
	if(nowPage == "server")
		ServerRename(filename);
	else if ( nowPage == "local" )
		LocalRename(filename);
}

//파일 다운로드 현황판 표시
function showUpDownProgressbar() {
	document.getElementById("IndicatorCurrent").style.width = "0px";
	document.getElementById("indicator").style.width = "0px";
	document.getElementById("ProgressnumCurrent").innerHTML = "0";
	document.getElementById("progressnum").innerHTML = "0";

	updown_progressbar = $('#updown_progressbar');

	updown_progressbar.show();
}

// 파일 다운로드 현황판 숨김
function hiddenUpDownProgressbar() {
	$('#updown_progressbar').hide();
}

// 파일 다운로드 취소
function updownCancel() {
	hiddenUpDownProgressbar();
	UpDownManager.cancel("", "");	
}
