/***************		logSettingForm		***************/
// 로그인 설정 기본값 설정
function getLogInfo() {
	auto= GetlocalStorage("auto");
	secureStatus= GetlocalStorage("secureStatus");
	
	check= document.getElementsByName('onoffswitch');
	if(auto == "true")	check[0].checked= true;
	if(secureStatus == "true")	check[1].checked= true;
}

// 자동 로그인, 보안 접속 상태 저장
function saveLogSet() {
	check= document.getElementsByName('onoffswitch');
	
	// 자동로그인/보안접속 여부 저장
	SetlocalStorage("auto", check[0].checked);
	SetlocalStorage("secureStatus", check[1].checked);
	// 로그인 유형 저장
	loginType= document.getElementsByName('loginType');
	if(loginType != null) {
		if(loginType[2].checked)		SetlocalStorage("setLoginType", loginType[2].value);
		else if(loginType[1].checked)	SetlocalStorage("setLoginType", loginType[1].value);
		else							SetlocalStorage("setLoginType", loginType[0].value);
	}
	
	navigator.notification.alert(logSetting_alert_save_setting, null, 'Setting', 'OK');
}

/***************		serInfoForm		***************/
// 서버 설정 기본값 설정
function getSerInfo() {
	serInfo_ip= GetlocalStorage("webserver");
	serInfo_port= GetlocalStorage("port");
	serInfo_securityPort= GetlocalStorage("securityPort");
	
	if(serInfo_port == null)	serInfo_port= '80';
	if(serInfo_securityPort == null)	serInfo_securityPort= '443';
	
	if(serInfo_ip != null)	$('#serInfo_ip').val(serInfo_ip);
	$('#serInfo_port').val(serInfo_port);
	$('#serInfo_securityPort').val(serInfo_securityPort);
}

// 서버 정보화면 서버 입력칸 클릭 시 focus on
function serInfo_ip_focus() {
	document.getElementById('serInfo_ip').focus();
}

//서버 정보화면 포트 입력칸 클릭 시 focus on
function serInfo_port_focus() {
	document.getElementById('serInfo_port').focus();
}

//서버 정보화면 보안접속 포트 입력칸 클릭 시 focus on
function serInfo_securityPort_focus() {
	document.getElementById('serInfo_securityPort').focus();
}

//서버 정보 저장
function saveServer() {
	var server= $('#serInfo_ip').val();
	var port= $('#serInfo_port').val();
	var securityPort= $('#serInfo_securityPort').val();
	
	SetlocalStorage("webserver", server);
	SetlocalStorage("port", port);
	SetlocalStorage("securityPort", securityPort);
	
	navigator.notification.alert(serInfo_alert_save_setting, null, 'Setting', 'OK');
}

/***************		regDeviceForm	***************/
//디바이스 등록 기본값 설정
function getRegDevInfo() {
	tmpAgent = GetlocalStorage("Platform");
    try{
	tmpDeviceID = GetlocalStorage("DeviceID");
	tmpServerIP= GetlocalStorage("webserver");
	tmpUserID= GetlocalStorage("id");

    
	if(tmpAgent == "11")		tmpAgent= "IPhone";
	else if(tmpAgent == "12")	tmpAgent= "AndroidPhone";
	else if(tmpAgent == "13")	tmpAgent= "Windows";
	else 						tmpAgent= "Tablet";
	
	tmpDeviceID1= tmpDeviceID.substr(0, 25);
	tmpDeviceID2= tmpDeviceID.substr(25);
	tmpDeviceID= tmpDeviceID1 + " " + tmpDeviceID2;
	
	$('#deviceInfo_id').text(tmpDeviceID);
	$('#deviceInfo_model').text(tmpAgent);
	if(tmpServerIP != null)	$('#regDevice_ip').text(tmpServerIP);
	$('#regDevice_id').val(tmpUserID);
        
    }catch(e){
        alert('getRegDevInfo() err = ' + e);
    }
}

// 디바이스 등록화면 아이디 입력칸 클릭 시 focus on
function regDevice_id_focus() {
	document.getElementById('regDevice_id').focus();
}

// 디바이스 등록화면 비밀번호 입력칸 클릭 시 focus on
function regDevice_passwd_focus() {
	document.getElementById('regDevice_passwd').focus();
}

//디바이스 등록
function regDevice() {
//    AM = new AppManager();
//    AM.auth_check(check_regDevice,null);
    check_regDevice();
}

function check_regDevice() {
    try{
        protocol= "http";
        var server= $('#regDevice_ip').text();
        var id= $('#regDevice_id').val();
        var password= $('#regDevice_passwd').val();
        
        // setting port
        if(server.indexOf(":") == -1) {
            port= "80";
            SSLPort= "443";
        }
        else {
            port= server.substring(server.lastIndexOf(":")+ 1);
            SSLPort= server.substring(server.lastIndexOf(":")+ 1);
            server= server.substring(0, server.lastIndexOf(":"));
        }
        
        if(server == "") {
            navigator.notification.alert(regDev_alert_insert_server, null, 'Login', 'OK');
            return;
        }
        if(id == "") {
            navigator.notification.alert(regDev_alert_insert_id, null, 'Login', 'OK');
            return;
        }
        if(password == "") {
            navigator.notification.alert(regDev_alert_insert_password, null, 'Login', 'OK');
            return;
        }
        
        getserverinfo(protocol, port, server);
        tmpDeviceID= GetlocalStorage("DeviceID");
        pushid= GetlocalStorage("PUSHID");
        DeviceInfo= device.name + "\t" + device.platform +"\t" + tmpDeviceID + "\t" + device.version +"\t"+tmpAgent;
        value= DeviceInfo+"\t"+id+"\t"+password+"\t"+pushid;
        SetlocalStorage("webserver", server);
        SetlocalStorage("id", id);
        
        cryptutil= new CryptUtil();
        cryptutil.call(
                       function(r) {
                       loginRetArr= new Array();
                       loginRetArr= r.split("\t");
                       
                       tmpparaData= "DeviceName=" + loginRetArr[0] + ";DevicePlatform=" + loginRetArr[1] + ";DeviceID=" + loginRetArr[2] + ";SofewareVer=" + loginRetArr[3]+";ModelName="+loginRetArr[4]
                       + ";UserID=" + loginRetArr[5] + ";Password=" + loginRetArr[6]+ ";PushRegID=" + loginRetArr[7];
                       tmpCookie= "PlusVersion=version 1.0"+ ";RegSession="+ loginRetArr[8];
                       LoginparaData= "Server="+server+"&Port="+port+"&Url="+"/webapp/device_reg_request.jsp"+"&CookieData="+tmpCookie+"&ParamData="+tmpparaData;
                       
                       useProxy = GetlocalStorage("useProxy");
                       if(useProxy == "true"){
                       us = new ProxyConnect();
                       us.proxyconn(successProxy, function(){alert('fail');}, protocol, port, server, "POST", "/webapp/protocal_mgmt.jsp", LoginparaData);
                       } else {
                       LoginRetVal= AjaxRequest(protocol, port, server, "POST", "/webapp/protocal_mgmt.jsp", LoginparaData);
                       var checkretvalArr= new Array();
                       checkretvalArr= LoginRetVal.split("\r\n");
                       if("version 1.0" == checkretvalArr[0].toLowerCase()) {
                       if("success" == checkretvalArr[1].toLowerCase())
                       navigator.notification.alert(regDev_alert_success, null,'Login','OK');
                       else if(checkretvalArr[1] == "Need Approval")
                       navigator.notification.alert(regDev_alert_needs_approval, null, 'Login', 'OK');
                       else if(checkretvalArr[1] == "Already Exist")
                       navigator.notification.alert(regDev_alert_already_exist, null, 'Login', 'OK');
                       else if(checkretvalArr[1] == "Not Exist User")
                       navigator.notification.alert(regDev_alert_not_exist_user, null, 'Login', 'OK');
                       else if(checkretvalArr[1] == "Exceeds Device Number")
                       navigator.notification.alert(regDev_alert_exceeds_number, null, 'Login', 'OK');
                       else if(checkretvalArr[1] == "Incorrect Password")
                       navigator.notification.alert(regDev_alert_wrong_user_iofo, null, 'Login', 'OK');
                       } else
                       navigator.notification.alert(LoginRetVal, null, 'Login', 'OK');
                       }
                       }, function(e){alert("Device regist ERR: "+ e)}, value, GetlocalStorage("SiteID"));
    }catch(e){
        alert('regDevice() err = ' + e);
    }
}


function successReg(LoginRetVal){
    var checkretvalArr= new Array();
    checkretvalArr= LoginRetVal.split("\r\n");
    if("version 1.0" == checkretvalArr[0].toLowerCase()) {
        if("success" == checkretvalArr[1].toLowerCase())
            navigator.notification.alert(regDev_alert_success, null,'Login','OK');
        else if(checkretvalArr[1] == "Need Approval")
            navigator.notification.alert(regDev_alert_needs_approval, null, 'Login', 'OK');
        else if(checkretvalArr[1] == "Already Exist")
            navigator.notification.alert(regDev_alert_already_exist, null, 'Login', 'OK');
        else if(checkretvalArr[1] == "Not Exist User")
            navigator.notification.alert(regDev_alert_not_exist_user, null, 'Login', 'OK');
        else if(checkretvalArr[1] == "Exceeds Device Number")
            navigator.notification.alert(regDev_alert_exceeds_number, null, 'Login', 'OK');
        else if(checkretvalArr[1] == "Incorrect Password")
            navigator.notification.alert(regDev_alert_wrong_user_iofo, null, 'Login', 'OK');
    } else
        navigator.notification.alert(LoginRetVal, null, 'Login', 'OK');
}

function failReg(e){
    alert("Device regist ERR: "+ e)
}
/***************		extConfoForm	***************/
function extConfo_ip_focus() {
	document.getElementById('extConfo_ip').focus();
}

function extConfo_port_focus() {
	document.getElementById('extConfo_port').focus();
}

// 외부접속 정보 저장
function saveExtSet() {
	var ip= $('#extConfo_ip').val();
	var port= $('#extConfo_port').val();
	useProxy= document.getElementsByName('onoffswitch');
	
    SetlocalStorage("ip", ip);
    SetlocalStorage("proxyPort", port);
    SetlocalStorage("useProxy", useProxy[2].checked);
    
        /*
	pp= new ProxyPlugin();
	pp.save("", function(e) {
		navigator.notification.alert(extConfo_alert_save_fail+ ": "+ e, null, 'Setting', 'OK');
		}, ip, port, useProxy[2].checked);
    }catch(e){
        alert('err = ' + e);
    }
         */
}


// 외부접속 정보 불러오기
function getExtConfo() {
    ip = GetlocalStorage("ip");
    port = GetlocalStorage("proxyPort");
    useProxy = GetlocalStorage("useProxy");
    $('#extConfo_ip').val(ip);
    $('#extConfo_port').val(port);
    proxySwitch = document.getElementsByName('onoffswitch');
    if(useProxy == "true")	proxySwitch[2].checked= true;
    else					proxySwitch[2].checked= false;

    /*
	pp= new ProxyPlugin();
	pp.load(setExtConfo, function(e){alert("Get external Connect information ERR: "+ e);});
*/
}

/* 불러온 외부접속 정보 삽입
 * getExtConfo() -> setExtConfo()
 */
function setExtConfo(retVal) {

	retValArray= retVal.split("\t");
	$('#extConfo_ip').val(retValArray[0]);
	$('#extConfo_port').val(retValArray[1]);
	useProxy= document.getElementsByName('onoffswitch');
	if(retValArray[2] == "true")	useProxy[2].checked= true;
	else							useProxy[2].checked= false;
}
