function SetsessionStorage(name, value) {
	sessionStorage.setItem(name, value);
}

function SetlocalStorage(name, value) {
	localStorage.setItem(name, value);
}

function GetsessionStorage(name) {
	return sessionStorage.getItem(name);
}
	
function GetlocalStorage(name) {
	return localStorage.getItem(name);
}

function ClearlocalStorage(name) {
	localStorage.removeItem(name);
}